classdef BeamSteering < handle

    properties
        channelSimulation   % Object of the channel simulation (e.g., ChannelGeneration)
        SNR                 % Signal-to-Noise Ratio (linear scale)
        spectralEfficiency  % Spectral efficiency calculated for the beamforming scheme
    end

    methods
        function obj = BeamSteering(SNR, Channel)
            % Constructor to initialize SNR and channel simulation object.
            obj.channelSimulation = Channel;
            obj.SNR = SNR;  % SNR provided in linear scale
            obj.launch();   % Launch the beamforming process
        end

        function obj = launch(obj)
            % Main function to perform beamforming using precoding and combining.
            
            % Find the indices of the steering vectors that maximize the effective channel gain
            [indexArrResponseTx, indexArrResponseRx] = obj.findSteeringVector();
            
            % Extract the channel matrix from the channel simulation object
            H = obj.channelSimulation.channelMatrix;
            
            % Initialize empty matrices for the transmit and receive beamforming vectors
            F_BS = [];  % Transmit beamforming matrix
            W_BS = [];  % Receive combining matrix

            % Select the steering vectors corresponding to the data streams
            for n = 1:obj.channelSimulation.numberDataStreams
                % Append the transmit steering vector for the nth data stream
                F_BS = [F_BS, obj.channelSimulation.arrayResponseTx(:, indexArrResponseTx(n))];
                % Append the receive steering vector for the nth data stream
                W_BS = [W_BS, obj.channelSimulation.arrayResponseRx(:, indexArrResponseRx(n))];
            end

            % Normalize the precoding matrix by applying a power scaling factor.
            % This ensures that the total transmitted power is maintained.
            powerScalingFactor = sqrt(obj.channelSimulation.numberDataStreams) / norm(F_BS, 'fro');
            F_BS = F_BS * powerScalingFactor;

            % Compute the effective channel matrix considering beamforming vectors
            Heff = W_BS' * H * F_BS;

            % Calculate the singular values of the effective channel matrix (for MIMO capacity)
            singularValues = svd(Heff);

            % Compute the spectral efficiency based on the singular values and SNR.
            % Spectral efficiency is the sum of the capacity for each singular value.
            obj.spectralEfficiency = 0;
            for k = 1:length(singularValues)
                obj.spectralEfficiency = obj.spectralEfficiency + ...
                    log2(1 + (obj.SNR / obj.channelSimulation.numberDataStreams) * (singularValues(k)^2));
            end
        end

        function [indexArrResponseTx, indexArrResponseRx] = findSteeringVector(obj)
            % This function finds the steering vectors at the transmitter and receiver 
            % that correspond to the maximum effective channel gain for each data stream.
            % It returns the indices of the selected steering vectors for the transmitter and receiver.

            numberPath = size(obj.channelSimulation.arrayResponseTx, 2); % Number of possible steering vectors (paths)
            H = obj.channelSimulation.channelMatrix;                      % Channel matrix from the simulation
            numStreams = obj.channelSimulation.numberDataStreams;         % Number of data streams

            % Preallocate matrix to store the effective gain for each combination of transmit and receive steering vectors
            effectiveGain = zeros(numberPath, numberPath);

            % Compute the effective channel gain for every combination of transmit and receive steering vectors
            for t = 1:numberPath
                for r = 1:numberPath
                    % Calculate the absolute value of the effective channel gain
                    effectiveGain(r, t) = abs(obj.channelSimulation.arrayResponseRx(:, r)' * H * obj.channelSimulation.arrayResponseTx(:, t));
                end
            end

            % Initialize index arrays for selected transmit and receive steering vectors
            indexArrResponseTx = zeros(numStreams, 1);  % Indices of selected transmit steering vectors
            indexArrResponseRx = zeros(numStreams, 1);  % Indices of selected receive steering vectors

            % Boolean arrays to mark whether a steering vector has been selected
            selectedTx = false(numberPath, 1);  % Marks selected transmit steering vectors
            selectedRx = false(numberPath, 1);  % Marks selected receive steering vectors

            % For each data stream, select the best transmit and receive steering vectors
            for n = 1:numStreams
                % Set already selected vectors to 0 to avoid re-selection
                effectiveGainTemp = effectiveGain;
                effectiveGainTemp(selectedRx, :) = 0;  % Exclude already selected receive vectors
                effectiveGainTemp(:, selectedTx) = 0;  % Exclude already selected transmit vectors

                % Find the maximum effective channel gain from the remaining options
                [maxGain, maxIndex] = max(effectiveGainTemp(:));
                if maxGain == 0
                    warning('No more unique beam pairs available.');  % Warn if no more beam pairs are available
                    break;
                end

                % Convert the linear index to row (receive) and column (transmit) indices
                [r, t] = ind2sub([numberPath, numberPath], maxIndex);

                % Store the selected transmit and receive steering vector indices
                indexArrResponseTx(n) = t;
                indexArrResponseRx(n) = r;

                % Mark the selected steering vectors as used
                selectedTx(t) = true;
                selectedRx(r) = true;
            end
        end
    end
end


