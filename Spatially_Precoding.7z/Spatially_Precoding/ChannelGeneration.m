classdef ChannelGeneration < handle
    % Simulation of channel environment and optimization types.

    properties
        numberTransmitAntennas  % Number of transmit antennas
        numberRecieveAntennas   % Number of receive antennas
        numberDataStreams       % Number of data streams
        numberRFChains          % Number of RF chains used for precoding and combining
        numberCluster           % Number of clusters
        numberRayPerCluster     % Number of rays per cluster
        angularSpread           % Angular spread in degrees
    end
    properties (Access=public)
        channelMatrix           % Channel matrix for the MIMO system
        arrayResponseTx         % Array response vector for the transmitter
        arrayResponseRx         % Array response vector for the receiver
        alpha                   % Complex path gain for each ray
    end

    methods
        function obj = ChannelGeneration(parameters)
            % Constructor to initialize the parameters from input.
            obj.numberTransmitAntennas = parameters("numberTransmitAntennas");
            obj.numberRecieveAntennas = parameters("numberRecieveAntennas");
            obj.numberDataStreams = parameters("numberDataStreams");
            obj.numberRFChains = parameters("numberRFChains");
            obj.numberCluster = parameters("numberCluster");
            obj.numberRayPerCluster = parameters("numberRayPerCluster");
            obj.angularSpread = parameters("angularSpread");
            obj.launch();  % Call the launch function to simulate the channel
        end

        function obj = launch(obj)
            % Main function to simulate the channel and calculate all required properties.
            
            % Define azimuth angle range for clusters in degrees
            minAOD = -60;  % Minimum angle of departure (AOD)
            maxAOD = 60;   % Maximum angle of departure (AOD)
            
            % Randomly generate cluster angles for both AOD (transmitter) and AOA (receiver)
            clusterAOD = rand(obj.numberCluster, 1) * (maxAOD - minAOD) + minAOD; % Cluster AOD values in the range [-60, 60] degrees
            clusterAOA = rand(obj.numberCluster, 1) * (maxAOD - minAOD) + minAOD; % Cluster AOA values in the range [-60, 60] degrees
            
            % Define angular spread scaling factor
            % The angular spread determines the variation in the angles of the rays around the cluster angle.
            b = obj.angularSpread / sqrt(2);  % Scale factor for angular spread, in degrees
            rndm = randn(obj.numberRayPerCluster * obj.numberCluster, 1); % Random Gaussian variables for ray angles

            % Generate angles for each ray by adding random variation to the cluster angles
            rayAOD = repelem(clusterAOD, obj.numberRayPerCluster, 1) + b * rndm; % AOD for each ray
            rayAOA = repelem(clusterAOA, obj.numberRayPerCluster, 1) + b * rndm; % AOA for each ray

            % Convert angles from degrees to radians
            rayAOD_rad = deg2rad(rayAOD);  % AOD in radians
            rayAOA_rad = deg2rad(rayAOA);  % AOA in radians

            % Obtain the position vectors of antennas for both transmitter and receiver arrays
            [txPosition, rxPosition] = obj.obtainPositionVectors();

            % Compute array response vectors based on the antenna positions and ray angles
            % The array response describes the phase shifts introduced by the angles of the incoming/outgoing rays.
            obj.arrayResponseTx = (1 / sqrt(obj.numberTransmitAntennas)) * exp(1i * pi * txPosition * sin(rayAOD_rad.'));
            obj.arrayResponseRx = (1 / sqrt(obj.numberRecieveAntennas)) * exp(1i * pi * rxPosition * sin(rayAOA_rad.'));

            % Generate complex path gains for each ray (channel coefficient)
            obj.generateComplexGainPath();

            % Generate the complete MIMO channel matrix using the computed array responses and path gains
            obj.generateChannelMatrix();
        end

        function [txPosition, rxPosition] = obtainPositionVectors(obj)
            %% Obtain the position vectors of antenna elements (normalized by half-wavelength)
            % Transmit antenna array positions - Uniform Linear Array (ULA) along the Z-axis
            txPosition = (0:obj.numberTransmitAntennas - 1).'; % Position vector of transmitter antennas (n_t x 1)

            % Receive antenna array positions - ULA along the Z-axis
            rxPosition = (0:obj.numberRecieveAntennas - 1).'; % Position vector of receiver antennas (n_r x 1)
        end

        function obj = generateComplexGainPath(obj)
            % Generate complex path gains for each ray, following a zero-mean, unit-variance complex Gaussian distribution.
            % This represents the random nature of the channel gains between antennas.
            obj.alpha = sqrt(1/2) * (randn(1, obj.numberRayPerCluster * obj.numberCluster) + ...
                                     1i * randn(1, obj.numberRayPerCluster * obj.numberCluster)); % Complex Gaussian random variable
        end

        function obj = generateChannelMatrix(obj)
            % Compute the MIMO channel matrix for the system
            % The channel matrix combines the array responses of the transmitter and receiver and the complex path gains.
            % Formula: H = sqrt(N_t * N_r / (N_cluster * N_ray)) * arrayResponseRx * diag(alpha) * arrayResponseTx'
            obj.channelMatrix = sqrt((obj.numberTransmitAntennas * obj.numberRecieveAntennas) / ...
                (obj.numberRayPerCluster * obj.numberCluster)) * ...
                obj.arrayResponseRx * diag(obj.alpha) * obj.arrayResponseTx';
        end
    end
end
