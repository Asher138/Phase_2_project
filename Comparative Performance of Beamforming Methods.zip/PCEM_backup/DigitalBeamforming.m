classdef DigitalBeamforming < handle

    properties
        channelSimulation   % Object of the channel simulation (e.g., ChannelGeneration)
        SNR_dB              % Signal-to-Noise Ratio in dB
        spectralEfficiency  % Spectral efficiency calculated for the beamforming scheme
        energyEfficiency    % Energy efficiency calculated for the beamforming scheme
        % Hardware power consumption parameters (in Watts)
        P_RF_chain = 100e-3;  % Power per RF chain (100 mW)
        P_PS = 10e-3;         % Power per phase shifter (10 mW)
        P_static = 100e-3;    % Static power consumption (100 mW)
        P_CP = 34.5;             % Consumed power when L_t = 4
        P_T = 10e-3;          % Power per transmit antenna (10 mW)
        P_R = 10e-3;          % Power per receive antenna (10 mW)
        eta_PA = 0.4;         % Amplifier efficiency (1/beta = 0.4)
        P_tx_max = 1;        % Maximum transmit power in Watts
    end

    methods
        function obj = DigitalBeamforming(SNR_dB, Channel)
            % Constructor to initialize SNR and channel simulation object.
            obj.channelSimulation = Channel;
            obj.SNR_dB = SNR_dB;  % SNR in dB
            obj.launch();   % Launch the beamforming process
        end

        function obj = launch(obj)
            % Main function to perform digital beamforming using SVD.

            % Extract the channel matrix from the channel simulation object
            H = obj.channelSimulation.channelMatrix;

            % Perform SVD on the channel matrix
            [U_H, Sigma_H, V_H] = svd(H);

            % Number of data streams
            Ns = obj.channelSimulation.numberDataStreams;
            Nr = obj.channelSimulation.numberReceiveAntennas;
            % Number of transmit antennas
            Nt = obj.channelSimulation.numberTransmitAntennas;

            % Select the first Ns columns of V_H and U_H
            V_H1 = V_H(:, 1:Ns);
            U_H1 = U_H(:, 1:Ns);
            Sigma_H1 = Sigma_H(1:Ns, 1:Ns);  % Singular values for the Ns streams

            % Fixed total transmit power (P_tx)
            

            % Calculate noise variance (sigma2) for the desired SNR
            SNR_linear = 10^(obj.SNR_dB / 10);
            % Noise variance sigma_n^2 = P_tx / SNR
            N_0 = 1.38e-23 *290;
            sigma2 = N_0;

            % Power allocation per stream (equal power allocation)
            
            P_tx = SNR_linear * sigma2 ;
            P_per_stream = P_tx / Ns;
            P_TX = P_per_stream * eye(Ns);  % Diagonal matrix with P_per_stream on the diagonal
            % Construct the optimal precoding matrix F_opt
            F_opt = V_H1 * sqrt(P_TX);

            % Ensure that the total transmit power constraint is satisfied
            total_power = norm(F_opt, 'fro')^2;
            
            if abs(total_power - P_tx) > 1e-6
                % Scale F_opt to satisfy the power constraint
                scaling_factor = sqrt(P_tx / total_power);
                F_opt = F_opt * scaling_factor;
            end

            % The receive combining matrix W_opt
            W_opt = U_H1;
            P_RF = obj.P_RF_chain;
            % Compute the effective channel
            Heff = W_opt' * H * F_opt;
            P_CP = obj.P_CP;        % Computational processing power
            P_T = obj.P_T;          % Power per transmit antenna
            P_R = obj.P_R;          % Power per receive antenna
            % Compute the spectral efficiency
            obj.spectralEfficiency = 0;
            for k = 1:Ns
                % Singular value for the kth stream
                lambda_k = Sigma_H1(k, k);

                % Calculate the SNR per stream
                gamma_k = (P_per_stream * (lambda_k^2)) / sigma2;
                P_alloc(k) = (SNR_linear * sigma2) / (lambda_k^2);
                
                % Ignore gamma_k if very small (gamma_k < 1e-12)
                if gamma_k < 1e-12
                    continue;
                end

                % Add the spectral efficiency of the kth stream
                obj.spectralEfficiency = obj.spectralEfficiency + log2(1 + gamma_k);
            end

            %% Updated Total Power Consumption Calculation
            beta = 1 / obj.eta_PA;
            % Number of RF chains for digital beamforming
            N_RF_Digital = Nt;  % N_RF = N_t (number of transmit antennas)
            % Total transmit power used
            tr_P_TX = sum(diag(P_TX));; % Total transmit power

            % Total power consumption calculation
            totalPowerDigital = beta * tr_P_TX+ 2 * P_CP + Nt * P_T + Nr * P_R ...
                + Nt * P_RF + Nr * P_RF;


            % Compute the energy efficiency
            obj.energyEfficiency = obj.spectralEfficiency / totalPowerDigital;

        end
    end
end