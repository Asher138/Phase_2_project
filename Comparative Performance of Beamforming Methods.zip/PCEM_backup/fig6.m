clear all
snrValuesDB = 0:5:25; % SNR values in dB
tryNumber = 1000; % Number of channel realizations for averaging

%% Simulation Parameters
parameters = containers.Map('KeyType','char','ValueType','any');
parameters("numberTransmitAntennas") = 64; 
parameters("numberReceiveAntennas") = 16; 
parameters("numberDataStreams") = 4;
parameters("numberRFChains") = 4;
parameters("numberCluster") = 8;
parameters("numberRayPerCluster") = 10;
parameters("angularSpread") = 7.5;
parameters("meanAODRange") = [60, 120];
parameters("meanAOARange") = [80, 100];
parameters("angleDistribution") = 'Laplacian';

% Hardware power consumption parameters (in Watts)
P_RF_chain = 100e-3; 
P_CP = 10;            
P_PS = 10e-3;         
P_T = 10e-3;          
P_R = 10e-3;          
eta_PA = 0.4;         
P_tx_max = 1;         

% Preallocate storage for spectral and energy efficiencies
spectralEffDigital = zeros(tryNumber, length(snrValuesDB));
energyEffDigital = zeros(tryNumber, length(snrValuesDB));

spectralEffAnalog = zeros(tryNumber, length(snrValuesDB));
energyEffAnalog = zeros(tryNumber, length(snrValuesDB));

spectralEffDinkelbach = zeros(tryNumber, length(snrValuesDB));
energyEffDinkelbach = zeros(tryNumber, length(snrValuesDB));

spectralEffBruteForce = zeros(tryNumber, length(snrValuesDB));
energyEffBruteForce = zeros(tryNumber, length(snrValuesDB));

spectralEffPCEMBrute = zeros(tryNumber, length(snrValuesDB));
energyEffPCEMBrute = zeros(tryNumber, length(snrValuesDB));

% Progress bar
h = waitbar(0, 'Progress...');

totalSteps = length(snrValuesDB) * tryNumber; 
currentStep = 0; 

for s = 1:length(snrValuesDB)
    SNR_dB = snrValuesDB(s);
    for i = 1:tryNumber
        channel = ChannelGeneration(parameters);

        %% Digital Beamforming
        digitalBF = DigitalBeamforming(SNR_dB, channel);
        digitalBF.P_RF_chain = P_RF_chain;
        digitalBF.P_CP = P_CP;
        digitalBF.P_T = P_T;
        digitalBF.P_R = P_R;
        digitalBF.eta_PA = eta_PA;

        spectralEffDigital(i, s) = digitalBF.spectralEfficiency;
        energyEffDigital(i, s) = digitalBF.energyEfficiency;

        %% Analog Beamforming
        analogBF = AnalogBeamforming(SNR_dB, channel);
        analogBF.P_RF_chain = P_RF_chain;
        analogBF.P_PS = P_PS;
        analogBF.P_CP = P_CP;
        analogBF.P_T = P_T;
        analogBF.P_R = P_R;
        analogBF.eta_PA = eta_PA;
        analogBF.P_tx_max = P_tx_max;

        spectralEffAnalog(i, s) = analogBF.spectralEfficiency;
        energyEffAnalog(i, s) = analogBF.energyEfficiency;

        %% Dinkelbach Method
        dinkelbachBF = DinkelbachMethod(SNR_dB, channel);
        dinkelbachBF.P_RF_chain = P_RF_chain;
        dinkelbachBF.P_T = P_T;
        dinkelbachBF.P_R = P_R;
        dinkelbachBF.P_CP = P_CP;
        dinkelbachBF.P_PS = P_PS;
        dinkelbachBF.eta_PA = eta_PA;
        dinkelbachBF.P_tx_max = P_tx_max;

        spectralEffDinkelbach(i, s) = dinkelbachBF.spectralEfficiency;
        energyEffDinkelbach(i, s) = dinkelbachBF.energyEfficiency;

        %% Brute Force Method
        bruteForceBF = BruteForce(SNR_dB, channel);
        bruteForceBF.P_RF_chain = P_RF_chain;
        bruteForceBF.P_T = P_T;
        bruteForceBF.P_R = P_R;
        bruteForceBF.P_CP = P_CP;
        bruteForceBF.P_PS = P_PS;
        bruteForceBF.eta_PA = eta_PA;
        bruteForceBF.P_tx_max = P_tx_max;

        spectralEffBruteForce(i, s) = bruteForceBF.spectralEfficiency;
        energyEffBruteForce(i, s) = bruteForceBF.energyEfficiency;

        %% PCEM & Brute Force (Single User)
        % Here we assume single user scenario. Set userDistance=100 (for instance) and userAngle=0
        userDistance = 100; userAngle = 0; 
        L_t = parameters("numberRFChains");

        pcemBruteBF = PCEM_BruteForce_SingleUser(SNR_dB, {channel}, L_t, userDistance, userAngle);
        pcemBruteBF.P_RF_chain = P_RF_chain;
        pcemBruteBF.P_PS = P_PS;
        pcemBruteBF.P_CP = P_CP;
        pcemBruteBF.P_T = P_T;
        pcemBruteBF.P_R = P_R;
        pcemBruteBF.eta_PA = eta_PA;

        % Use pcemBruteBF's PCEM solution or brute force solution stored inside it
        % For consistency, let's take the PCEM result from it:
        spectralEffPCEMBrute(i, s) = pcemBruteBF.totalSpectralEfficiency;
        energyEffPCEMBrute(i, s) = pcemBruteBF.totalEnergyEfficiency;

        % Update progress bar
        currentStep = currentStep + 1;
        waitbar(currentStep / totalSteps, h, sprintf('Progress: %d%%', round(100 * currentStep / totalSteps)));
    end
end

close(h);

% Averaging over trials
spectralEffDigitalSNR = mean(spectralEffDigital, 1); 
energyEffDigitalSNR = mean(energyEffDigital, 1);

spectralEffAnalogSNR = mean(spectralEffAnalog, 1); 
energyEffAnalogSNR = mean(energyEffAnalog, 1);

spectralEffDinkelbachSNR = mean(spectralEffDinkelbach, 1); 
energyEffDinkelbachSNR = mean(energyEffDinkelbach, 1);

spectralEffBruteForceAvg = mean(spectralEffBruteForce, 1);
energyEffBruteForceAvg = mean(energyEffBruteForce, 1);

spectralEffPCEMBruteAvg = mean(spectralEffPCEMBrute, 1);
energyEffPCEMBruteAvg = mean(energyEffPCEMBrute, 1);

% Plotting the spectral efficiency
figure(); 
% Use distinct colors and markers for each line
plot(snrValuesDB, spectralEffDigitalSNR, '-o', 'Color', [0 0.5 0], 'LineWidth', 2.0, 'MarkerSize', 8.0); hold on;
plot(snrValuesDB, spectralEffAnalogSNR, '-x', 'Color', [1 0 0], 'LineWidth', 2.0, 'MarkerSize', 8.0);
plot(snrValuesDB, spectralEffDinkelbachSNR, '-d', 'Color', [0.5 0 0.5], 'LineWidth', 2.0, 'MarkerSize', 8.0);
plot(snrValuesDB, spectralEffBruteForceAvg, '-s', 'Color', [0 0 1], 'LineWidth', 2.0, 'MarkerSize', 8.0);
plot(snrValuesDB, spectralEffPCEMBruteAvg, '-^', 'Color', [0.8 0.5 0.2], 'LineWidth', 2.0, 'MarkerSize', 8.0);

legend('Digital BF','Analog BF','Dinkelbach','Brute Force','PCEM & Brute Force','Location', 'northwest', 'FontSize', 15);
xlabel('SNR (dB)', 'FontSize', 20)
ylabel('Spectral Efficiency (bits/s/Hz)', 'FontSize', 20)
grid on
title('Spectral Efficiency vs SNR', 'FontSize', 20)
hold off;

% Plotting the energy efficiency
figure(); 
plot(snrValuesDB, energyEffDigitalSNR, '-o', 'Color', [0 0.5 0], 'LineWidth', 2.0, 'MarkerSize', 8.0); hold on;
plot(snrValuesDB, energyEffAnalogSNR, '-x', 'Color', [1 0 0], 'LineWidth', 2.0, 'MarkerSize', 8.0);
plot(snrValuesDB, energyEffDinkelbachSNR, '-d', 'Color', [0.5 0 0.5], 'LineWidth', 2.0, 'MarkerSize', 8.0);
plot(snrValuesDB, energyEffBruteForceAvg, '-s', 'Color', [0 0 1], 'LineWidth', 2.0, 'MarkerSize', 8.0);
plot(snrValuesDB, energyEffPCEMBruteAvg, '-^', 'Color', [0.8 0.5 0.2], 'LineWidth', 2.0, 'MarkerSize', 8.0);

legend('Digital BF','Analog BF','Dinkelbach','Brute Force','PCEM & Brute Force','Location', 'northwest', 'FontSize', 15);
xlabel('SNR (dB)', 'FontSize', 20)
ylabel('Energy Efficiency (bits/Joule)', 'FontSize', 20)
grid on
title('Energy Efficiency vs SNR', 'FontSize', 20)
hold off;
