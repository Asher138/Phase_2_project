classdef PCEM_BruteForce_SingleUser < handle
    % PCEM_BruteForce_SingleUser 
    % This class implements the PCEM algorithm for a single-user scenario and 
    % also performs a brute force search over transmit power to compare results.

    properties
        channelSimulations     % Cell array with one channel simulation object (single user)
        K                      % Number of users, should be 1 for single-user scenario
        H_cells                % Cell array of channel matrices for the user {1} (N_r x N_t)
        F_analog               % Analog precoding matrix (N_t x L_t)
        F_digital_cells        % Cell array with one digital precoding matrix (L_t x N_s)
        W_analog_cells         % Cell array with one analog combiner (N_r x L_r)
        W_digital_cells        % Cell array with one digital combiner (L_r x N_s)
        singular_values_cells  % Cell array of singular values (N_s x 1)
        totalSpectralEfficiency    % Total spectral efficiency (bits/s/Hz)
        totalEnergyEfficiency      % Total energy efficiency (bits/Joule)
        perUserSpectralEfficiency  % Spectral efficiency per user (here just one user)
        perUserEnergyEfficiency    % Energy efficiency per user (here just one user)
        perUserOptimalPt           % Optimal transmit power per user (Watts) from PCEM

        % Hardware power parameters (Watts)
        P_RF_chain = 100e-3;  
        P_PS = 10e-3;         
        P_CP = 10;            
        P_T = 10e-3;          
        P_R = 10e-3;          
        eta_PA = 0.4;         
        L_t                 
        SNR_dB              
        userDistances       % Distance of the single user
        averageDistance     
        userAngles          % Optional, not necessarily used

        % Timing measurements
        beamTrainingTime   
        precodingTime      
        dataCommTime       
        totalTime

        % Brute force results
        bruteForceTime      
        bruteForcePt        
        bruteForceSE        
        bruteForceEE        
    end

    methods
        function obj = PCEM_BruteForce_SingleUser(SNR_dB, ChannelSimulations, L_t, userDistance, userAngle)
            % For single-user scenario: 
            % ChannelSimulations is a cell with 1 channel object
            obj.SNR_dB = SNR_dB;
            obj.channelSimulations = ChannelSimulations; 
            obj.K = length(ChannelSimulations); % Should be 1 for single-user
            obj.L_t = L_t;
            obj.userDistances = userDistance; % Single value if single-user
            obj.userAngles = userAngle;       % Optional
            obj.launch();
        end

        function obj = launch(obj)
            totalTimeStart = tic;

            %% Step 1: Beam Training Part
            beamTrainingStart = tic;

            % System parameters
            fc = 28e9;         
            c = 3e8;           
            alpha = 2;         
            d_min = 10;        
            d_max = 200;       

            lambda = c / fc;   
            K = obj.K;         

            E_gamma_inv = (d_max^(alpha + 2) - d_min^(alpha + 2)) / ((1 + alpha / 2) * (d_max^2 - d_min^2));

            obj.H_cells = cell(K, 1);
            for k = 1:K
                H_k = obj.channelSimulations{k}.channelMatrix;
                d_k = obj.userDistances(k);
                pathLoss_k = (d_k^alpha) / E_gamma_inv;
                H_k = H_k / sqrt(pathLoss_k);
                obj.H_cells{k} = H_k;
            end

            obj.averageDistance = mean(obj.userDistances);
            obj.beamTrainingTime = toc(beamTrainingStart);

            %% Step 2: Initialize V_ARF and W_ARF
            precodingStart = tic;

            Nt = obj.channelSimulations{1}.numberTransmitAntennas;
            Ns = obj.channelSimulations{1}.numberDataStreams;
            L_t = obj.L_t;
            K = obj.K;
            Nr = obj.channelSimulations{1}.numberReceiveAntennas;
            L_r = L_t;

            V_ARF = exp(1j * 2 * pi * rand(Nt, L_t)); 
            obj.F_analog = V_ARF; 

            W_ARF_cells = cell(K, 1);
            for k = 1:K
                W_ARF_k = exp(1j * 2 * pi * rand(Nr, L_r));
                W_ARF_cells{k} = W_ARF_k;
            end
            obj.W_analog_cells = W_ARF_cells;

            max_iterations = 10;
            tol = 1e-4;
            V_DBB_cells = cell(K, 1);
            W_DBB_cells = cell(K, 1);

            for iter = 1:max_iterations
                for k = 1:K
                    H_k = obj.H_cells{k};
                    H_eff_k = W_ARF_cells{k}' * H_k * V_ARF;

                    [U_k, ~, V_k] = svd(H_eff_k);
                    U_k = U_k(:, 1:Ns);
                    V_k = V_k(:, 1:Ns);

                    V_DBB_k = sqrt(Ns)*V_k;
                    V_DBB_k = V_DBB_k / norm(V_ARF*V_DBB_k,'fro')*sqrt(Ns);
                    V_DBB_cells{k} = V_DBB_k;

                    W_DBB_k = sqrt(Ns)*U_k;
                    W_DBB_k = W_DBB_k / norm(W_ARF_cells{k}*W_DBB_k,'fro')*sqrt(Ns);
                    W_DBB_cells{k} = W_DBB_k;
                end

                numerator = zeros(Nt, L_t);
                for k = 1:K
                    numerator = numerator + V_ARF * V_DBB_cells{k} * V_DBB_cells{k}';
                end
                V_ARF_old = V_ARF;
                V_ARF = exp(1j * angle(numerator));
                obj.F_analog = V_ARF;

                for k = 1:K
                    numerator_w = W_ARF_cells{k} * W_DBB_cells{k} * W_DBB_cells{k}';
                    W_ARF_k = exp(1j * angle(numerator_w));
                    W_ARF_cells{k} = W_ARF_k;
                    obj.W_analog_cells{k} = W_ARF_k;
                end

                if norm(V_ARF - V_ARF_old,'fro')/norm(V_ARF_old,'fro')<tol
                    break;
                end
            end

            obj.F_digital_cells = V_DBB_cells;
            obj.W_digital_cells = W_DBB_cells;
            obj.precodingTime = toc(precodingStart);

            %% Step 6: Data Communication and Power Optimization Part
            dataCommStart = tic;

            beta = 1/obj.eta_PA;
            if L_t == Nt
                Pc = 2*obj.P_CP + Nt*(obj.P_RF_chain+obj.P_T) + Nr*(obj.P_RF_chain+obj.P_R);
            else
                Pc = 2 * obj.P_CP + Nt * obj.P_T + Nr * obj.P_R ...
                    + L_t*(obj.P_RF_chain + Nt*obj.P_PS) ...
                    + L_t*(obj.P_RF_chain + Nr*obj.P_PS);
            end

            k_boltz = 1.38e-23;
            T = 290;
            B = 20e6;
            sigma2_noise = k_boltz*T*B;
            SNR_linear_desired = 10^(obj.SNR_dB/10);

            % Compute \| V_ARF V_DBB \|_F^2
            V_hybrid_norm_sq=0;
            for k=1:K
                V_total_k = obj.F_analog * obj.F_digital_cells{k};
                V_hybrid_norm_sq = V_hybrid_norm_sq + norm(V_total_k,'fro')^2;
            end

            d_min=10; d_max=200; alpha=2;
            E_gamma_inv = (d_max^(alpha+2)-d_min^(alpha+2))/((1+alpha/2)*(d_max^2-d_min^2));
            a3 = (B*alpha^2*K*V_hybrid_norm_sq)/obj.eta_PA * E_gamma_inv;

            P_RF = obj.P_RF_chain; P_PS = obj.P_PS; P_c = obj.P_CP; P_LNA = obj.P_R;
            Nt = obj.channelSimulations{1}.numberTransmitAntennas;
            Nr = obj.channelSimulations{1}.numberReceiveAntennas;
            Ns = obj.channelSimulations{1}.numberDataStreams;

            a4 = Nt*P_RF + Nr*P_RF + Nt*P_PS + P_c*Nt + P_LNA*(K*Nr+K);

            a2_total =0;
            p_k = zeros(K,1);
            for k=1:K
                W_ARF_k = obj.W_analog_cells{k};
                W_DBB_k = obj.W_digital_cells{k};
                W_total_k = W_ARF_k*W_DBB_k;
                V_DBB_k = obj.F_digital_cells{k};
                V_total_k = obj.F_analog*V_DBB_k;
                H_k = obj.H_cells{k};

                temp_matrix = W_total_k'*H_k*V_total_k;
                numerator = abs(trace(temp_matrix))^2;
                denominator = norm(W_total_k,'fro')^2 * sigma2_noise;
                a2_k = numerator/denominator;
                a2_total = a2_total+a2_k;
                p_k(k)=(SNR_linear_desired*denominator)/numerator;
            end

            a2 = a2_total/K;
            numerator_p = a4*a2 - a3;
            denominator_p = a3*exp(1);
            epsilon=1e-10;
            lambert_arg = max(numerator_p/denominator_p, -1/exp(1)+epsilon);
            W_value = real(lambertw(lambert_arg));
            p_eq30 = max((exp(W_value-1)-1)/a2,0);
            p_eq2 = max(p_k);
            p = max(p_eq30, p_eq2);

            P_tp = p*K;
            T_tot =1; U_total=1000; a1=K*(1-(T_tot*K)/U_total);
            argument = 1+p*a2;
            if argument>0
                R_K = a1*log2(argument);
            else
                R_K=0;
            end
            totalPowerConsumption = P_tp+Pc;
            obj.totalSpectralEfficiency = R_K;
            obj.totalEnergyEfficiency = R_K/totalPowerConsumption;
            obj.perUserSpectralEfficiency = R_K/K;
            obj.perUserOptimalPt = p;
            obj.perUserEnergyEfficiency = (R_K/K)/(p+Pc/K);

            obj.dataCommTime = toc(dataCommStart);

            %% Brute Force Search over p
            % After PCEM calculation, do a brute force search
            bruteForceStart = tic;

            % Define a search range for p
            Pt_min = p_eq2; 
            Pt_max_search = max(p_eq30*100, p*100);
            if Pt_max_search < 1e-6
                Pt_max_search = 1;
            end
            numPoints=100;
            Pt_values = linspace(Pt_min, Pt_max_search, numPoints);
            bestEE = -Inf; bestSE=0; bestPtBF=Pt_min;

            % Extract singular values again
            singular_values_user = singular_values_for_one_user(obj, Ns);

            for i=1:numPoints
                Pt_candidate = Pt_values(i);
                gamma_cand = (Pt_candidate*singular_values_user.^2)/(Ns*sigma2_noise);
                SE_cand = sum(log2(1+gamma_cand));
                % Recompute Pc for single user scenario (same as above):
                if L_t == Nt
                    Pc_single = 2*obj.P_CP + Nt*(obj.P_RF_chain+obj.P_T) + Nr*(obj.P_RF_chain+obj.P_R);
                else
                    Pc_single = 2 * obj.P_CP + Nt * obj.P_T + Nr * obj.P_R ...
                        + L_t*(obj.P_RF_chain+Nt*obj.P_PS) ...
                        + L_t*(obj.P_RF_chain+Nr*obj.P_PS);
                end
                totalPower_cand = beta*Pt_candidate + Pc_single;
                EE_cand = SE_cand/totalPower_cand;
                if EE_cand>bestEE
                    bestEE=EE_cand;
                    bestSE=SE_cand;
                    bestPtBF=Pt_candidate;
                end
            end

            obj.bruteForceTime = toc(bruteForceStart);
            obj.bruteForcePt = bestPtBF;
            obj.bruteForceSE = bestSE;
            obj.bruteForceEE = bestEE;

            obj.totalTime = toc(totalTimeStart);
        end
    end
end

function val = objective_with_penalty(Pt, EE_fun, constraint_fun)
    penalty = 1e6;
    if constraint_fun(Pt)>=0
        val=EE_fun(Pt);
    else
        val=EE_fun(Pt)+penalty*abs(constraint_fun(Pt));
    end
end

function singular_values_user = singular_values_for_one_user(obj, Ns)
    % Extract singular values again after final precoding/combining
    W_ARF_k = obj.W_analog_cells{1};
    W_DBB_k = obj.W_digital_cells{1};
    W_total_k = W_ARF_k*W_DBB_k;
    V_DBB_k = obj.F_digital_cells{1};
    V_total_k = obj.F_analog*V_DBB_k;
    H_k = obj.H_cells{1};

    H_eff = W_total_k' * H_k * V_total_k;
    [~, S_eff, ~] = svd(H_eff);
    singular_values_user = diag(S_eff(1:Ns,1:Ns));
end
