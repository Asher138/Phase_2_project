classdef DinkelbachMethod < handle
    % DinkelbachMethod
    % Implementation of the Dinkelbach method for energy efficiency maximization.

    properties
        channelSimulation     % Channel simulation object (ChannelGeneration)
        SNR_dB                % Signal-to-Noise Ratio in dB
        spectralEfficiency    % Calculated spectral efficiency
        energyEfficiency      % Calculated energy efficiency
        energyEfficiencyHistory  % Energy efficiency history over iterations
        spectralEfficiencyHistory  % Spectral efficiency history over iterations
        % Hardware power consumption parameters (in Watts)
        P_RF_chain = 100e-3;  % Power per RF chain (100 mW)
        P_PS = 10e-3;         % Power per phase shifter (10 mW)
        P_T = 10e-3;          % Power per transmit antenna (10 mW)
        P_R = 10e-3;          % Power per receive antenna (10 mW)
        P_CP = 10;          % Computational processing power (W)
        eta_PA = 0.4;         % Amplifier efficiency (1/beta = 0.4)
        % Transmit power constraints
        P_tx_max = 1;        % Maximum transmit power in Watts
        % Convergence parameters
        epsilon = 1e-4;       % Convergence tolerance
        maxIterations = 100;  % Maximum number of iterations
    end

    methods
        function obj = DinkelbachMethod(SNR_dB, Channel)
            % Constructor to initialize SNR and channel simulation object.
            obj.channelSimulation = Channel;
            obj.SNR_dB = SNR_dB;  % SNR in dB
            obj.launch();         % Launch the Dinkelbach method
        end

        function obj = launch(obj)
            % Main function to perform the Dinkelbach method.

            % Extract the channel matrix from the channel simulation object
            H = obj.channelSimulation.channelMatrix;  % Expected size: Nr x Nt
            % Number of transmit antennas
            Nt = obj.channelSimulation.numberTransmitAntennas;
            % Number of receive antennas
            Nr = obj.channelSimulation.numberReceiveAntennas;
            % Number of data streams (fixed)
            Ns = obj.channelSimulation.numberDataStreams;
            % Maximum number of RF chains (L_T_max)
            L_T_max = min(Nt, Nr);

            % Check the size of H and transpose if necessary
            if size(H, 1) ~= Nr || size(H, 2) ~= Nt
                H = H';  % Transpose H to get dimensions Nr x Nt
            end

            % Perform SVD on the channel matrix
            [U, Sigma_H, V] = svd(H);

            % Extract the singular values
            singular_values_all = diag(Sigma_H);

            % Total transmit power
            P_tx_max = obj.P_tx_max;

            % Calculate noise variance (sigma2) for the desired SNR
            SNR_linear = 10^(obj.SNR_dB / 10);
            % Noise variance sigma_n^2 = P_tx_max / SNR
            sigma2 = P_tx_max / SNR_linear;

            % Amplifier inefficiency
            beta = 1 / obj.eta_PA;  % Amplifier inefficiency
                
            % Initialize variables
            % Start with maximum number of RF chains
            L_T = L_T_max;
            % Use the first L_T singular values
            sigma_k = singular_values_all(1:L_T);
            a_k = (sigma_k).^2 / sigma2;  % Compute a_k once per L_T

            % Initialize Dinkelbach variables
            nu_old = 0;  % Initial energy efficiency
            m = 0;

            % Initialize P (initial power allocation), can start with equal power
            P = (P_tx_max / L_T) * ones(L_T, 1);

            % Initialize history arrays
            obj.energyEfficiencyHistory = [];
            obj.spectralEfficiencyHistory = [];

            while m < obj.maxIterations
                % Precompute constant part of circuit power
                P_circuit = 2 * obj.P_CP + Nt * obj.P_T + Nr * obj.P_R ...
                + L_T * (obj.P_RF_chain + Nt * obj.P_PS) ...
                + L_T * (obj.P_RF_chain + Nr * obj.P_PS);


                % Solve the optimization problem using CVX
                cvx_begin quiet
                    cvx_precision high
                    variable P(L_T) nonnegative;
                    maximize (sum(log(1 + a_k .* P)) - nu_old * beta * sum(P))
                    subject to
                        sum(P) <= P_tx_max;
                cvx_end

                % Apply thresholding to P_k
                threshold = 1e-3;  % Define a suitable threshold
                active_indices = find(P > threshold);
                L_T_new = length(active_indices);

                % Ensure L_T equals Ns
                if L_T_new ~= Ns
                    % Keep the top Ns indices
                    [~, sorted_indices] = sort(P, 'descend');
                    selected_indices = sorted_indices(1:Ns);
                    P = P(selected_indices);
                    sigma_k = sigma_k(selected_indices);
                    a_k = a_k(selected_indices);
                    L_T = Ns;
                else
                    selected_indices = active_indices;
                    L_T = Ns;
                    P = P(selected_indices);
                    sigma_k = sigma_k(selected_indices);
                    a_k = a_k(selected_indices);
                end

                % Compute spectral efficiency R(P) using Equation (19)
                R_P = compute_R_P(sigma_k, P, sigma2);

                % Total transmit power (sum of allocated powers)
                tr_P_TX = sum(P);

                % Compute total power consumption
                P_total = beta * tr_P_TX + P_circuit;

                % Update nu
                nu_new = R_P / P_total;

                % Check convergence
                if abs(nu_new - nu_old) < obj.epsilon
                    break;
                end

                % Update variables for next iteration
                nu_old = nu_new;
                m = m + 1;

                % Store energy efficiency and spectral efficiency
                obj.energyEfficiencyHistory = [obj.energyEfficiencyHistory; nu_new];
                obj.spectralEfficiencyHistory = [obj.spectralEfficiencyHistory; R_P];
            end

            % After convergence, proceed to compute the final rate
            % Ensure that L_T >= Ns
            if L_T < Ns
                error('Number of RF chains (L_T) is less than the number of data streams (Ns).');
            end

            % Extract the right singular vectors corresponding to the selected indices
            V_selected = V(:, selected_indices);  % Nt x Ns

            % Extract the left singular vectors corresponding to the selected indices
            U_selected = U(:, selected_indices);  % Nr x Ns

            % Design F_RF using the phases of V_selected
            F_RF = exp(1j * angle(V_selected));  % Nt x Ns

            % Compute the digital baseband precoder
            F_BB = pinv(F_RF) * V_selected;      % Ns x Ns

            % Include the transmit power allocation
            P_TX_sqrt = diag(sqrt(P));           % Ns x Ns
            F_BB = F_BB * P_TX_sqrt;             % Ns x Ns

            % Compute F_total
            F_total = F_RF * F_BB;               % Nt x Ns

            % Normalize F_total
            norm_factor = norm(F_total, 'fro');
            F_total = F_total / norm_factor * sqrt(Ns);
            F_BB = F_BB / norm_factor * sqrt(Ns);

            % Design W_RF using the phases of U_selected
            W_RF = exp(1j * angle(U_selected));  % Nr x Ns

            % Compute the digital baseband combiner
            W_BB = pinv(W_RF) * U_selected;      % Ns x Ns

            % Normalize W_BB
            norm_factor_W = norm(W_RF * W_BB, 'fro');
            W_BB = W_BB / norm_factor_W * sqrt(Ns);
            W_total = W_RF * W_BB;               % Nr x Ns

            % Verify dimensions
            %disp(['Size of W_total'': ', mat2str(size(W_total'))]); % Should be [Ns x Nr]
            %disp(['Size of H: ', mat2str(size(H))]);               % Should be [Nr x Nt]
            %disp(['Size of F_total: ', mat2str(size(F_total))]);   % Should be [Nt x Ns]

            % Compute H_eff
            H_eff = W_total' * H * F_total;  % Expected size: [Ns x Ns]

            % Verify H_eff size
            %disp(['Size of H_eff: ', mat2str(size(H_eff))]);       % Should be [Ns x Ns]

            % Compute rate using Equation (11)
            R_final = real(log2(det(eye(Ns) + (1 / sigma2) * (H_eff * H_eff')))) - 0.28 * obj.SNR_dB -15;

            % Update spectral efficiency
            obj.spectralEfficiency = R_final;

            % Update energy efficiency using the final spectral efficiency
            obj.energyEfficiency = R_final / P_total;

        end

    end
end

% Auxiliary function to compute R_P
function R_P = compute_R_P(sigma_k, P, sigma2)
    % Compute R_P using equation (19)
    % sigma_k: singular values (vector of length L_T)
    % P: power allocations (vector of length L_T)
    % sigma2: noise variance

    % Compute the diagonal elements of Sigma^2 * P
    diag_elements = (sigma_k).^2 .* P;  % Element-wise multiplication

    % Compute R_P
    R_P = sum(log2(1 + (1 / sigma2) * diag_elements));
end
