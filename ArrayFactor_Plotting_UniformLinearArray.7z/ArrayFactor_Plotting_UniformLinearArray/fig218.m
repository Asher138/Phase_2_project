% Define parameters
N = 10;            % Number of array elements, increase N to display more sidelobes
d = 0.5;           % Element spacing, in terms of wavelength (lambda/2)
theta = linspace(-180, 540, 2000);  % Angle range in degrees, spanning from -180 to 540 degrees
lambda = 1;        % Wavelength
beta = 2 * pi / lambda;  % Wavenumber, beta represents the spatial frequency

% Generate u, which corresponds to cos(theta)
% a1 represents cos(theta) values for the range of -180 to 180 degrees
% a2 represents cos(theta) values shifted by 2 for a wider range
a1 = cosd(theta);
a2 = a1 + 2;  
u = [a1, a2];   % Concatenating the arrays to get a wider range of u values

% Calculate u, psi, and kz
psi = beta * d * u;         % psi = beta * d * cos(theta), representing phase shift in psi space
kz = beta * u;              % kz = beta * cos(theta), representing the normalized wavenumber (spatial frequency) in kz space

% Calculate array factor B_u using psi
psi_half = psi / 2;         % Dividing psi by 2 as the phase shift between elements
B_u = sin(N * psi_half) ./ (N * sin(psi_half));  % Array factor formula for a uniform linear array

% For theta-space calculation, focusing on the range between -180 to 180 degrees
psi_1 = beta * d * a1;         % Calculate psi for theta range between -180 and 180 degrees
psi_half1 = psi_1 / 2;         % Divide psi by 2
B_u1 = sin(N * psi_half1) ./ (N * sin(psi_half1));  % Array factor in the range of -180 to 180 degrees

% Handle singularities (where the denominator becomes zero) to avoid division by zero
singularities = find(abs(sin(psi_half)) < 1e-12);  % Identifying small values where sin(psi_half) approaches zero
B_u(singularities) = 1;  % Set those points to 1 to avoid NaN values

% Normalize the array factor
B_u = abs(B_u) / max(abs(B_u));  % Normalize the array factor B_u to ensure the maximum value is 1
B_u1 = abs(B_u1) / max(abs(B_u1));  % Normalize B_u1 similarly for plotting in theta space

% Plot the figures

% Plot 1: Beam pattern in kz-space
subplot(4,1,1);
plot(kz, B_u, 'LineWidth', 1.5);
xlabel('k_z');  % Label for the x-axis, representing kz
ylabel('Normalized |B(k_z)|');  % Label for the y-axis, representing normalized array factor in kz space
title('Beam Pattern in k_z-space');  % Title of the plot
grid on;  % Enable grid lines
axis([-2*pi 6*pi 0 1]);  % Set axis limits for kz space, expanding it to show more repeated patterns

% Plot 2: Beam pattern in psi-space
subplot(4,1,2);
plot(psi, B_u, 'LineWidth', 1.5);
xlabel('\psi (radians)');  % Label for the x-axis, representing psi in radians
ylabel('Normalized |B(\psi)|');  % Label for the y-axis, representing normalized array factor in psi space
title('Beam Pattern in \psi-space');  % Title of the plot
grid on;  % Enable grid lines
axis([-pi 3*pi 0 1]);  % Set axis limits for psi space to visualize multiple lobes

% Plot 3: Beam pattern in u-space
subplot(4,1,3);
plot(u, B_u, 'LineWidth', 1.5);
xlabel('u = cos(\theta)');  % Label for the x-axis, representing u as cos(theta)
ylabel('Normalized |B(u)|');  % Label for the y-axis, representing normalized array factor in u space
title('Beam Pattern in u-space');  % Title of the plot
grid on;  % Enable grid lines
axis([-1 3 0 1]);  % Set axis limits for u space, expanding the range to observe the repeated pattern

% Plot 4: Beam pattern in theta-space
subplot(4,1,4);
plot(theta, B_u1, 'LineWidth', 1.5);
xlabel('\theta (degrees)');  % Label for the x-axis, representing angle theta in degrees
ylabel('Normalized |B(\theta)|');  % Label for the y-axis, representing normalized array factor in theta space
title('Beam Pattern in \theta-space');  % Title of the plot
grid on;  % Enable grid lines
axis([-180 180 0 1]);  % Set axis limits for theta space, keeping it between -180 and 180 degrees
