% Main Script for Comparing PCEM Methods with Random and Fixed Distances
clear all
clc

snrValuesDB = 0:5:25; % SNR values in dB
tryNumber = 1000;      % Number of channel realizations for averaging

%% Simulation Parameters
parameters = containers.Map('KeyType','char','ValueType','any');
parameters("numberTransmitAntennas") = 64; % Number of transmit antennas at base station (M)
parameters("numberReceiveAntennas") = 12;   % Number of receive antennas per user (N_r)
parameters("numberDataStreams") = 1;       % Number of data streams (s)
parameters("numberRFChains") = 4;          % Number of RF chains (will be set to N_s)
parameters("numberCluster") = 8;           % Number of clusters (N_cl)
parameters("numberRayPerCluster") = 10;    % Number of rays per cluster (N_ray)
parameters("angularSpread") = 7.5;         % Angular spread in degrees

% Hardware power consumption parameters (in Watts)
P_RF_chain = 100e-3;  % Power per RF chain (100 mW)
P_PS = 10e-3;         % Power per phase shifter (10 mW)
P_CP = 10;            % Computational processing power (10 W)
P_T = 10e-3;          % Power per transmit antenna (10 mW)
P_R = 10e-3;          % Power per receive antenna (10 mW)
eta_PA = 0.4;         % Amplifier efficiency (1/beta = 0.4)

Nt = parameters("numberTransmitAntennas");
Ns = parameters("numberDataStreams");
L_t = Ns; % Set L_t = Ns

% Number of users
K = 4; % Fixed number of users as per your request
parameters("numberUsers") = K; % Set the number of users in parameters

% Initialize matrices to store spectral efficiency, energy efficiency, and transmit power
numMethods = 2; % Two methods: PCEM (random distances) and PCEMfixed (fixed average distance)
spectralEffAll = zeros(tryNumber, length(snrValuesDB), numMethods);
energyEffAll = zeros(tryNumber, length(snrValuesDB), numMethods);
txPowerAll = zeros(tryNumber, length(snrValuesDB), numMethods);

% Create progress bar
waitbarHandle = waitbar(0, 'Progress...');

totalSteps = length(snrValuesDB) * tryNumber * numMethods; % Total steps
currentStep = 0; % Current progress

for s = 1:length(snrValuesDB)
    SNR_dB = snrValuesDB(s);

    for i = 1:tryNumber
        % Generate channel simulations for each user
        channelSimulations = cell(K, 1);
        for k = 1:K
            channelSimulations{k} = ChannelGeneration(parameters);
        end

        %% Method 1: PCEM with Random Distances
        % Create PCEM instance with given L_t and K users
        pcemBF = PCEM(SNR_dB, channelSimulations, L_t);

        % Set hardware power parameters
        pcemBF.P_RF_chain = P_RF_chain;
        pcemBF.P_PS = P_PS;
        pcemBF.P_CP = P_CP;
        pcemBF.P_T = P_T;
        pcemBF.P_R = P_R;
        pcemBF.eta_PA = eta_PA;

        % Store the results for PCEM
        spectralEffAll(i, s, 1) = pcemBF.totalSpectralEfficiency;
        energyEffAll(i, s, 1) = pcemBF.totalEnergyEfficiency;
        txPowerAll(i, s, 1) = sum(pcemBF.perUserOptimalPt); % Total transmit power

        % Retrieve the average distance from the PCEM instance
        averageDistance = pcemBF.averageDistance;

        %% Method 2: PCEMfixed with Fixed Average Distance
        % Create PCEMfixed instance with same channels and parameters, and pass averageDistance
        pcemFixedBF = PCEMfixed(SNR_dB, channelSimulations, L_t, averageDistance);

        % Set hardware power parameters
        pcemFixedBF.P_RF_chain = P_RF_chain;
        pcemFixedBF.P_PS = P_PS;
        pcemFixedBF.P_CP = P_CP;
        pcemFixedBF.P_T = P_T;
        pcemFixedBF.P_R = P_R;
        pcemFixedBF.eta_PA = eta_PA;

        % Store the results for PCEMfixed
        spectralEffAll(i, s, 2) = pcemFixedBF.totalSpectralEfficiency;
        energyEffAll(i, s, 2) = pcemFixedBF.totalEnergyEfficiency;
        txPowerAll(i, s, 2) = sum(pcemFixedBF.perUserOptimalPt); % Total transmit power

        % Update progress bar
        currentStep = currentStep + 1;
        waitbar(currentStep / totalSteps, waitbarHandle, ...
            sprintf('Progress: %d%%', round(100 * currentStep / totalSteps)));
    end
end

% Close progress bar
close(waitbarHandle);

% Averaging over trials
spectralEffAvg = squeeze(mean(spectralEffAll, 1)); % Dimensions: [length(snrValuesDB), numMethods]
energyEffAvg = squeeze(mean(energyEffAll, 1));
txPowerAvg = squeeze(mean(txPowerAll, 1));

% Prepare legends for plots
legends = {'PCEM (Random Distances)', 'PCEMfixed (Fixed Average Distance)'};

% Plotting the total spectral efficiency vs SNR for both methods
figure();
markers = {'-s', '-o'};
colors = {[0 0.5 0], [1 0 0]};
hold on;
for method_idx = 1:numMethods
    plot(snrValuesDB, spectralEffAvg(:, method_idx), markers{method_idx}, 'Color', colors{method_idx}, ...
        'LineWidth', 2.0, 'MarkerSize', 8.0);
end
legend(legends, 'Location', 'northwest', 'FontSize', 12);
xlabel('SNR (dB)', 'FontSize', 14)
ylabel('Total Spectral Efficiency (bits/s/Hz)', 'FontSize', 14)
grid on
title('Total Spectral Efficiency vs SNR (K = 4)', 'FontSize', 16)
hold off;

% Plotting the total energy efficiency vs SNR for both methods
figure();
hold on;
for method_idx = 1:numMethods
    plot(snrValuesDB, energyEffAvg(:, method_idx), markers{method_idx}, 'Color', colors{method_idx}, ...
        'LineWidth', 2.0, 'MarkerSize', 8.0);
end
legend(legends, 'Location', 'best', 'FontSize', 12);
xlabel('SNR (dB)', 'FontSize', 14)
ylabel('Total Energy Efficiency (bits/Joule)', 'FontSize', 14)
grid on
title('Total Energy Efficiency vs SNR (K = 4)', 'FontSize', 16)
hold off;

% Plotting the average total transmit power vs SNR for both methods
figure();
hold on;
for method_idx = 1:numMethods
    plot(snrValuesDB, txPowerAvg(:, method_idx), markers{method_idx}, 'Color', colors{method_idx}, ...
        'LineWidth', 2.0, 'MarkerSize', 8.0);
end
legend(legends, 'Location', 'best', 'FontSize', 12);
xlabel('SNR (dB)', 'FontSize', 14)
ylabel('Average Total Transmit Power (Watts)', 'FontSize', 14)
grid on
title('Average Total Transmit Power vs SNR (K = 4)', 'FontSize', 16)
hold off;
