classdef PCEMfixed120 < handle
    % PCEMfixed120 Class with Fixed Average User Distance (120 Degrees)
    % Implementation of the Power Controlled Energy Maximization (PCEM) Algorithm with fixed user distances.

    properties
        channelSimulations     % Cell array of channel simulation objects for each user
        K                      % Number of users
        H_cells                % Cell array of channel matrices for each user (N_r x N_t)
        F_analog               % Common analog precoding matrix (N_t x L_t)
        F_digital_cells        % Cell array of digital precoding matrices for each user (L_t x N_s)
        W_analog_cells         % Cell array of analog combiners for each user (N_r x L_r)
        W_digital_cells        % Cell array of digital combiners for each user (L_r x N_s)
        totalSpectralEfficiency    % Total spectral efficiency of the system
        totalEnergyEfficiency      % Total energy efficiency of the system
        perUserSpectralEfficiency  % Spectral efficiency per user
        perUserEnergyEfficiency    % Energy efficiency per user
        perUserOptimalPt           % Optimal transmit power per user
        % Hardware power consumption parameters (in Watts)
        P_RF_chain = 100e-3;  % Power per RF chain (100 mW)
        P_PS = 10e-3;         % Power per phase shifter (10 mW)
        P_CP = 10;            % Computational processing power (10 W)
        P_T = 10e-3;          % Power per transmit antenna (10 mW)
        P_R = 10e-3;          % Power per receive antenna (10 mW)
        eta_PA = 0.4;         % Amplifier efficiency (1/beta = 0.4)
        L_t                  % Number of transmit RF chains (input)
        SNR_dB               % Desired Signal-to-Noise Ratio in dB
        % Added properties
        userDistances        % Distances of users (vector of length K)
        averageDistance      % Average of user distances (input from random case)
        userAngles           % Angles of users (vector of length K)
    end

    methods
        function obj = PCEMfixed120(SNR_dB, ChannelSimulations, L_t, averageDistance, userAngles)
            % Constructor to initialize SNR, channel simulations for multiple users,
            % number of RF chains, average distance from the random case, and user angles.
            obj.SNR_dB = SNR_dB;
            obj.channelSimulations = ChannelSimulations;
            obj.K = length(ChannelSimulations);
            obj.L_t = L_t;
            obj.averageDistance = averageDistance;
            obj.userAngles = userAngles;
            obj.launch();
        end

        function obj = launch(obj)
            % Main function to perform hybrid beamforming using the PCEMfixed120 method.


            % System parameters
            fc = 28e9;          % Carrier frequency (Hz)
            c = 3e8;            % Speed of light (m/s)
            alpha = 2;          % Path loss exponent
            d_min = 10;         % Minimum distance in meters

            % Number of users
            K = obj.K;

            % Use the average distance provided
            d_mean = obj.averageDistance;

            % Extract the channel matrices for each user and apply path loss
            obj.H_cells = cell(K, 1);
            obj.userDistances = d_mean * ones(K, 1); % Set all user distances to d_mean
            for k = 1:K
                H_k = obj.channelSimulations{k}.channelMatrix;

                % Set user distance to fixed average distance
                d_k = d_mean;
                obj.userDistances(k) = d_k;
                theta_k = obj.userAngles(k);

                % Optional: Store user locations in Cartesian coordinates
                x_k = d_k * cos(theta_k);
                y_k = d_k * sin(theta_k);
                % obj.userLocations{k} = [x_k, y_k];

                % Calculate path loss for user k
                pathLoss_k = (d_k / d_min)^alpha;  % Path loss relative to reference distance d_min

                % Apply path loss to channel matrix
                H_k = H_k / sqrt(pathLoss_k);
                obj.H_cells{k} = H_k;
            end


            %% Step 2: Initialize V_ARF and W_ARF with arbitrary angles
            precodingStart = tic;

            Nt = obj.channelSimulations{1}.numberTransmitAntennas;
            Ns = obj.channelSimulations{1}.numberDataStreams;
            L_t = obj.L_t;
            K = obj.K;
            Nr = obj.channelSimulations{1}.numberReceiveAntennas;
            L_r = L_t; % Assuming same number of RF chains at receiver

            % Initialize V_ARF with arbitrary angles
            V_ARF = exp(1j * 2 * pi * rand(Nt, L_t)); % Nt x L_t analog precoder
            % No normalization needed
            obj.F_analog = V_ARF; % Store analog precoder

            % Initialize W_ARF for each user with arbitrary angles
            W_ARF_cells = cell(K, 1);
            for k = 1:K
                W_ARF_k = exp(1j * 2 * pi * rand(Nr, L_r)); % Nr x L_r analog combiner
                % No normalization needed
                W_ARF_cells{k} = W_ARF_k;
            end
            obj.W_analog_cells = W_ARF_cells;

            %% Steps 3-5: Iterative Optimization of V_ARF, W_ARF, V_DBB, W_DBB
            max_iterations = 10;
            tol = 1e-4;
            V_DBB_cells = cell(K, 1);
            W_DBB_cells = cell(K, 1);

            for iter = 1:max_iterations
                % For each user, compute V_k
                for k = 1:K
                    H_k = obj.H_cells{k};

                    % Compute effective channel for user k
                    H_eff_k = W_ARF_cells{k}' * H_k * V_ARF;

                    % SVD of effective channel
                    [U_k, ~, V_k] = svd(H_eff_k);

                    % Select Ns singular vectors
                    U_k = U_k(:, 1:Ns);
                    V_k = V_k(:, 1:Ns);

                    % Compute digital precoder and combiner
                    V_DBB_k = sqrt(Ns) * V_k;
                    % Normalize V_DBB_k
                    V_DBB_k = V_DBB_k / norm(V_ARF * V_DBB_k, 'fro') * sqrt(Ns);
                    V_DBB_cells{k} = V_DBB_k;

                    W_DBB_k = sqrt(Ns) * U_k;
                    % Normalize W_DBB_k
                    W_DBB_k = W_DBB_k / norm(W_ARF_cells{k} * W_DBB_k, 'fro') * sqrt(Ns);
                    W_DBB_cells{k} = W_DBB_k;
                end

                % Update V_ARF
                numerator = zeros(Nt, L_t);
                for k = 1:K
                    numerator = numerator + V_ARF * V_DBB_cells{k} * V_DBB_cells{k}';
                end
                V_ARF_old = V_ARF;
                V_ARF = exp(1j * angle(numerator));
                % No normalization needed since |V_ARF| = 1
                obj.F_analog = V_ARF;

                % Update W_ARF for each user
                for k = 1:K
                    numerator_w = W_ARF_cells{k} * W_DBB_cells{k} * W_DBB_cells{k}';
                    W_ARF_k = exp(1j * angle(numerator_w));
                    % No normalization needed since |W_ARF_k| = 1
                    W_ARF_cells{k} = W_ARF_k;
                    obj.W_analog_cells{k} = W_ARF_k;
                end

                % Check for convergence
                if norm(V_ARF - V_ARF_old, 'fro') / norm(V_ARF_old, 'fro') < tol
                    break;
                end
            end

            % Store digital precoders and combiners
            obj.F_digital_cells = V_DBB_cells;
            obj.W_digital_cells = W_DBB_cells;


            %% Step 6: Data Communication and Power Optimization Part
            dataCommStart = tic;

            % Constants
            beta = 1 / obj.eta_PA;  % Amplifier inefficiency factor

            % Total circuit power consumption (excluding transmit power)
            Nt = obj.channelSimulations{1}.numberTransmitAntennas;
            Nr = obj.channelSimulations{1}.numberReceiveAntennas;
            Pc = 2 * obj.P_CP + Nt * obj.P_T + obj.K * Nr * obj.P_R ...
                + obj.L_t * (obj.P_RF_chain + Nt * obj.P_PS) ...
                + obj.K * L_r * (obj.P_RF_chain + Nr * obj.P_PS);

            % Noise variance sigma_n^2 (thermal noise)
            k_boltz = 1.38e-23;       % Boltzmann's constant (Joule per Kelvin)
            T = 290;                  % System temperature (Kelvin)
            B = 20e6;                 % Bandwidth (Hz)
            sigma2_noise = k_boltz * T * B;

            % Desired SNR in linear scale
            SNR_linear_desired = 10^(obj.SNR_dB / 10);

            % Compute constants a1, a2, a3, a4
            T_tot = 1; % Total time slots (adjust as needed)
            U_total = 1000;  % Total available resources (adjust as needed)

            a1 = obj.K * (1 - (T_tot * obj.K) / U_total);

            % Compute effective channel gains and norms
            % Compute \| V_ARF V_DBB \|_F^2
            V_hybrid_norm_sq = 0;
            for k = 1:obj.K
                V_total_k = obj.F_analog * obj.F_digital_cells{k};
                V_hybrid_norm_sq = V_hybrid_norm_sq + norm(V_total_k, 'fro')^2;
            end

            % Compute path loss for fixed average distance
            d_min = 10; % Reference distance
            alpha = 2;  % Path loss exponent
            pathLoss_fixed = (obj.averageDistance / d_min)^alpha;

            % Compute a3
            a3 = (B * alpha^2 * obj.K * V_hybrid_norm_sq) / obj.eta_PA * pathLoss_fixed;

            % Compute a4
            P_RF = obj.P_RF_chain;    % Power per RF chain
            P_PS = obj.P_PS;          % Power per phase shifter
            P_c = obj.P_CP;           % Computational processing power
            P_LNA = obj.P_R;          % Power per Low Noise Amplifier

            a4 = Nt * P_RF + Nr * P_RF + Nt * P_PS + P_c * Nt + P_LNA * (obj.K * Nr + obj.K);

            % Compute average a2 over users
            a2_total = 0;
            p_k = zeros(obj.K, 1); % Transmit power required per user based on Equation (2)

            for k = 1:obj.K
                W_ARF_k = obj.W_analog_cells{k};   % N_r x L_r
                W_DBB_k = obj.W_digital_cells{k};  % L_r x N_s
                % Effective combined combiner
                W_total_k = W_ARF_k * W_DBB_k;     % N_r x N_s
                V_DBB_k = obj.F_digital_cells{k};  % L_t x N_s
                % Effective combined precoder
                V_total_k = obj.F_analog * V_DBB_k; % N_t x N_s
                H_k = obj.H_cells{k};              % N_r x N_t

                % Compute numerator for a2_k: |trace(W_total_k^H * H_k * V_total_k)|^2
                temp_matrix = W_total_k' * H_k * V_total_k;  % N_s x N_s
                numerator = abs(trace(temp_matrix))^2;

                % Compute denominator for a2_k: ||W_total_k||_F^2 * sigma2_noise
                denominator = norm(W_total_k, 'fro')^2 * sigma2_noise;

                % Compute a2_k
                a2_k = numerator / denominator;
                a2_total = a2_total + a2_k;

                % Compute p_k for user k using Equation (2)
                p_k(k) = (SNR_linear_desired * denominator) / numerator;
            end
            a2 = a2_total / obj.K; % Average over K users

            % Compute p using Equation (30)
            numerator_p = a4 * a2 - a3;
            denominator_p = a3 * exp(1);
            epsilon = 1e-10;
            lambert_arg = max(numerator_p / denominator_p, -1/exp(1) + epsilon);

            % Compute the Lambert W function value
            W_value = real(lambertw(lambert_arg));

            % Compute p from Equation (30) and ensure it's non-negative
            p_eq30 = max((exp(W_value - 1) - 1) / a2, 0);

            % Compute p required to satisfy SNR per Equation (2)
            p_eq2 = max(p_k);

            % Choose p as the maximum of p_eq30 and p_eq2
            p = max(p_eq30, p_eq2);

            % Compute total transmit power P_tp
            P_tp = p * obj.K; % Total transmit power for all users

            % Compute R_K using Equation (3)
            argument = 1 + p * a2;
            if argument > 0
                R_K = a1 * log2(argument);
            else
                R_K = 0; % Spectral efficiency is zero if argument is non-positive
            end

            % Compute total power consumption
            totalPowerConsumption = P_tp + Pc;

            % Compute total energy efficiency
            obj.totalSpectralEfficiency = R_K;
            obj.totalEnergyEfficiency = obj.totalSpectralEfficiency / totalPowerConsumption;

            % For per-user metrics
            obj.perUserSpectralEfficiency = R_K / obj.K * ones(obj.K, 1);
            obj.perUserOptimalPt = p * ones(obj.K, 1);
            obj.perUserEnergyEfficiency = obj.perUserSpectralEfficiency ./ (p + Pc / obj.K);

        end
    end
end
