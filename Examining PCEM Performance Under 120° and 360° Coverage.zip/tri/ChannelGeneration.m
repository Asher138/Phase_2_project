classdef ChannelGeneration < handle
    % ChannelGeneration
    % Simulation of channel environment using the specified mmWave channel model.

    properties
        numberTransmitAntennas  % Number of antennas at the base station (M)
        numberReceiveAntennas   % Number of receive antennas per user (N_r)
        numberDataStreams       % Number of data streams (s)
        numberRFChains          % Number of RF chains used for precoding and combining
        numberCluster           % Number of clusters (N_cl)
        numberRayPerCluster     % Number of rays per cluster (N_ray)
        angularSpread           % Angular spread in degrees (not used in this model)
    end
    properties (Access=public)
        channelMatrix           % Channel matrix for the MIMO system (G)
        arrayResponseTx         % Array response vectors at the transmitter for each path
        arrayResponseRx         % Array response vectors at the receiver for each path
        alpha                   % Complex path gain for each ray (a_l)
    end

    methods
        function obj = ChannelGeneration(parameters)
            % Constructor to initialize the parameters from input.
            obj.numberTransmitAntennas = parameters("numberTransmitAntennas"); % M
            obj.numberReceiveAntennas = parameters("numberReceiveAntennas");   % N_r
            obj.numberDataStreams = parameters("numberDataStreams");           % s
            obj.numberRFChains = parameters("numberRFChains");
            obj.numberCluster = parameters("numberCluster");                   % N_cl
            obj.numberRayPerCluster = parameters("numberRayPerCluster");       % N_ray
            obj.angularSpread = parameters("angularSpread");                   % Not used in this model
            obj.launch();  % Call the launch function to simulate the channel
        end

        function obj = launch(obj)
            % Main function to simulate the channel using the specified model.

            % Physical constants
            c = 3e8;          % Speed of light (m/s)
            fc = 28e9;        % Carrier frequency (Hz)
            lambda = c / fc;  % Wavelength (m)
            d = lambda / 2;   % Inter-element spacing (m)
            k = 2 * pi / lambda; % Wave number

            % Number of antennas at base station and user
            M = obj.numberTransmitAntennas; % Transmit antennas at base station
            N_r = obj.numberReceiveAntennas; % Receive antennas per user

            % Total number of paths (rays)
            N_p = obj.numberCluster * obj.numberRayPerCluster; % N_p = N_cl * N_ray

            % Initialize arrays to store path gains and angles
            a_l = zeros(N_p, 1);          % Path gain coefficients

            % Generate path gains and angles for each path
            for l = 1:N_p
                % Generate path gain a_l as complex Gaussian with zero mean and unit variance
                a_l(l) = (1 / sqrt(2)) * (randn + 1i * randn);
            end

            % Generate random angles of departure and arrival for each path
            phi_M_l = 2 * pi * rand(N_p, 1); % AOD at base station for user
            phi_K_l = 2 * pi * rand(N_p, 1); % AOA at user terminal

            % Compute array response vectors at transmitter and receiver
            a_M = zeros(M, N_p); % Transmit array response (M x N_p)
            a_K = zeros(N_r, N_p); % Receive array response (N_r x N_p)

            for l = 1:N_p
                % Transmit array response for path l
                a_M(:, l) = obj.arrayResponse(M, phi_M_l(l), k, d); % M x 1

                % Receive array response for path l
                a_K(:, l) = obj.arrayResponse(N_r, phi_K_l(l), k, d); % N_r x 1
            end

            % Accumulate the channel matrix for user
            G = zeros(N_r, M);
            for l = 1:N_p
                G = G + sqrt(M * N_r / N_p) * a_l(l) * a_K(:, l) * a_M(:, l)'; % (N_r x 1) * (1 x M)
            end

            % Store the channel matrix and array responses
            obj.channelMatrix = G; % Channel matrix for this user (N_r x M)
            obj.arrayResponseTx = a_M; % Transmit array responses (M x N_p)
            obj.arrayResponseRx = a_K; % Receive array responses (N_r x N_p)
            obj.alpha = a_l; % Path gains
        end

        function a = arrayResponse(obj, numAntennas, phi, k, d)
            % Compute the array response vector for a ULA with numAntennas elements.
            % a(φ) = (1 / sqrt(M)) * [1, e^{jkd sin(φ)}, ..., e^{jkd(M-1) sin(φ)}]^T

            % Antenna element indices
            n = (0:numAntennas - 1).'; % Column vector

            % Compute the array response vector
            a = (1 / sqrt(numAntennas)) * exp(1i * k * d * n * sin(phi));
        end
    end
end
