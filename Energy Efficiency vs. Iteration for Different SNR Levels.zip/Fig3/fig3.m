% Main Script for Energy Efficiency vs. Iteration (Analog Beamforming and Dinkelbach Method)
clear all;
clc;

% Simulation Parameters
parameters = containers.Map('KeyType','char','ValueType','any');
parameters("numberTransmitAntennas") = 64;  % Number of transmit antennas (N_T)
parameters("numberReceiveAntennas") = 16;   % Number of receive antennas (N_R)
parameters("numberDataStreams") = 4;        % Number of data streams (N_s)
parameters("numberRFChains") = 4;           % Number of RF chains
parameters("numberCluster") = 8;            % Number of clusters (N_cl)
parameters("numberRayPerCluster") = 10;     % Number of rays per cluster (N_ray)
parameters("angularSpread") = 7.5;          % Angular spread in degrees
parameters("meanAODRange") = [60, 120];     % Mean angles of departure range in degrees
parameters("meanAOARange") = [80, 100];     % Mean angles of arrival range in degrees
parameters("angleDistribution") = 'Laplacian'; % Angle distribution

% SNR values to simulate
snrValuesDB = [-10, 0, 10];

% Initialize cell arrays to store energy efficiency histories
EE_histories = cell(length(snrValuesDB), 1);

% Total number of steps for the wait bar
totalSteps = length(snrValuesDB);
currentStep = 0;

% Create wait bar
waitbarHandle = waitbar(0, 'Simulation in progress...');

% Generate the channel once to use the same channel for all SNRs
channel = ChannelGeneration(parameters);

% Loop over SNR values
for idx = 1:length(snrValuesDB)
    SNR_dB = snrValuesDB(idx);

    % Instantiate AnalogBeamforming to get energy efficiency for iteration 1
    analogBF = AnalogBeamforming(SNR_dB, channel);
    EE_analog = analogBF.energyEfficiency;

    % Create DinkelbachMethod instance
    dinkelbach = DinkelbachMethod(SNR_dB, channel);

    % Extract energy efficiency history from Dinkelbach method (iterations 2-5)
    EE_history_dinkelbach = dinkelbach.energyEfficiencyHistory;
    
    if length(EE_history_dinkelbach) < 4
        last_value = EE_history_dinkelbach(end);
        % Pad with the last value to reach 4 entries
        EE_history_dinkelbach = [EE_history_dinkelbach; repmat(last_value, 4 - length(EE_history_dinkelbach), 1)];
    end
    
    % Combine analog beamforming and Dinkelbach method energy efficiencies
    EE_history = [EE_analog; EE_history_dinkelbach];

    % Store the combined energy efficiency history
    EE_histories{idx} = EE_history;

    % Update wait bar
    currentStep = currentStep + 1;
    waitbar(currentStep / totalSteps, waitbarHandle, sprintf('Processing SNR = %d dB (%d of %d)', SNR_dB, idx, totalSteps));
end

% Close wait bar
close(waitbarHandle);

% Plotting Energy Efficiency vs. Iteration
figure();
hold on;
markers = {'-o', '-s', '-d'};
colors = {[0 0.4470 0.7410], [0.8500 0.3250 0.0980], [0.9290 0.6940 0.1250]};
legends = cell(length(snrValuesDB), 1);

for idx = 1:length(snrValuesDB)
    EE_history = EE_histories{idx};
    iterations = 1:length(EE_history);
    plot(iterations, EE_history, markers{idx}, 'Color', colors{idx}, 'LineWidth', 2, 'MarkerSize', 8);
    legends{idx} = sprintf('SNR = %d dB', snrValuesDB(idx));
end

xlabel('Iteration', 'FontSize', 14);
ylabel('Energy Efficiency (bits/Joule)', 'FontSize', 14);
title('Energy Efficiency vs. Iteration', 'FontSize', 16);
legend(legends, 'FontSize', 12, 'Location', 'best');
grid on;
hold off;
