classdef AnalogBeamforming < handle
    % AnalogBeamforming 
    % Implementation of analog beamforming, calculating both spectral and energy efficiency.

    properties
        channelSimulation     % Channel simulation object (ChannelGeneration)
        SNR_dB                % Signal-to-Noise Ratio in dB
        spectralEfficiency    % Calculated spectral efficiency
        energyEfficiency      % Calculated energy efficiency
        % Hardware power consumption parameters (in Watts)
        P_RF_chain = 100e-3;  % Power per RF chain (100 mW)
        P_PS = 10e-3;         % Power per phase shifter (10 mW)
        P_CP = 10;             % Common power of TX (10 W)
        P_T = 10e-3;          % Power per transmit antenna (10 mW)
        P_R = 10e-3;          % Power per receive antenna (10 mW)
        eta_PA = 0.4;         % Amplifier efficiency (1/beta = 0.4)
        P_tx_max = 10;        % Maximum transmit power in Watts
    end

    methods
        function obj = AnalogBeamforming(SNR_dB, Channel)
            % Constructor to initialize SNR and channel simulation object.
            obj.channelSimulation = Channel;
            obj.SNR_dB = SNR_dB;  % SNR in dB
            obj.launch();         % Launch the beamforming process
        end

        function obj = launch(obj)
            % Main function to perform analog beamforming.

            % Extract the channel matrix from the channel simulation object
            H = obj.channelSimulation.channelMatrix;

            % Number of transmit and receive antennas
            Nt = obj.channelSimulation.numberTransmitAntennas;
            Nr = obj.channelSimulation.numberReceiveAntennas;

            

            % Calculate noise variance (sigma2) for the desired SNR
            SNR_linear = 10^(obj.SNR_dB / 10);
            % Noise variance sigma_n^2 = P_tx / SNR
            N_0 = 1.38e-23 *290;
            sigma2 = N_0;

            % Perform SVD on the channel matrix
            [U_H, ~, V_H] = svd(H);

            % Analog precoding vector (transmit beamforming vector)
            f_RF = V_H(:, 1);
            f_RF = exp(1j * angle(f_RF)) / sqrt(Nt);  % Normalize to constant modulus

            % Analog combining vector (receive beamforming vector)
            w_RF = U_H(:, 1);
            w_RF = exp(1j * angle(w_RF)) / sqrt(Nr);  % Normalize to constant modulus

            % Calculate the effective channel gain
            effectiveChannelGain = abs(w_RF' * H * f_RF)^2;

            % Compute the spectral efficiency
            obj.spectralEfficiency = log2(1 + effectiveChannelGain * SNR_linear);

            
            % Calculate required transmit power
            P_tx_required = SNR_linear * sigma2;
            % Compute the total power consumption according to the equation
            % Ensure transmit power does not exceed maximum allowed power
            P_tx = min(P_tx_required, obj.P_tx_max);

            beta = 1 / obj.eta_PA;  % Amplifier inefficiency
            tr_P_TX = P_tx;         % Total transmit power

            P_CP = obj.P_CP;        % Computational processing power
            P_T = obj.P_T;          % Power per transmit antenna
            P_R = obj.P_R;          % Power per receive antenna

            L_T_opt = 1;            % Number of active RF chains at transmitter
            L_R_opt = 1;            % Number of active RF chains at receiver
            P_CP = obj.P_CP;
            P_RF = obj.P_RF_chain;  % Power per RF chain
            P_PS = obj.P_PS;        % Power per phase shifter

            % Total power consumption calculation
            totalPowerAnalog = beta * tr_P_TX + 2 * P_CP + Nt * P_T + Nr * P_R ...
                + L_T_opt * (P_RF + Nt * P_PS) + L_R_opt * (P_RF + Nr * P_PS);

            % Compute the energy efficiency
            obj.energyEfficiency = obj.spectralEfficiency / totalPowerAnalog;
        end
    end
end
