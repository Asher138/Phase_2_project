classdef DinkelbachMethod < handle
    % DinkelbachMethod
    % Implementation of the Dinkelbach method for energy efficiency maximization.

    properties
        channelSimulation     % Channel simulation object (ChannelGeneration)
        SNR_dB                % Signal-to-Noise Ratio in dB
        spectralEfficiency    % Calculated spectral efficiency
        energyEfficiency      % Calculated energy efficiency
        energyEfficiencyHistory  % Energy efficiency history over iterations
        spectralEfficiencyHistory  % Spectral efficiency history over iterations
        % Hardware power consumption parameters (in Watts)
        P_RF_chain = 100e-3;  % Power per RF chain (100 mW)
        P_PS = 10e-3;         % Power per phase shifter (10 mW)
        P_T = 10e-3;          % Power per transmit antenna (10 mW)
        P_R = 10e-3;          % Power per receive antenna (10 mW)
        P_CP = 10;            % Computational processing power (10 W)
        eta_PA = 0.4;         % Amplifier efficiency (1/beta = 0.4)
        % Transmit power constraints
        P_tx_max = 1;        % Maximum transmit power in Watts
        % Convergence parameters
        epsilon = 1e-4;       % Convergence tolerance
        maxIterations = 100;    % Maximum number of iterations
        % Timing properties
        beamTrainingTime      % Time taken for Beam Training part
        dinkelbachTime        % Time taken for Dinkelbach method part
        dataCommTime          % Time taken for Data Communication part
        totalTime             % Total time taken
    end

    methods
        function obj = DinkelbachMethod(SNR_dB, Channel)
            % Constructor to initialize SNR and channel simulation object.
            obj.channelSimulation = Channel;
            obj.SNR_dB = SNR_dB;  % SNR in dB
            obj.launch();         % Launch the Dinkelbach method
        end

        function obj = launch(obj)
            % Main function to perform the Dinkelbach method.

            totalTimeStart = tic;  % Start total time measurement

            % Extract the channel matrix from the channel simulation object
            H = obj.channelSimulation.channelMatrix;
            % Number of transmit antennas
            Nt = obj.channelSimulation.numberTransmitAntennas;
            % Number of receive antennas
            Nr = obj.channelSimulation.numberReceiveAntennas;
            % Maximum number of data streams (RF chains)
            L_T_max = min(Nt, Nr);

            % --- Beam Training Time measurement ---
            beamTrainingStart = tic;

            % Perform SVD on the channel matrix
            [U, Sigma_H, V] = svd(H);

            % Extract the singular values
            singular_values_all = diag(Sigma_H);

            obj.beamTrainingTime = toc(beamTrainingStart);
            % --- End of Beam Training Time measurement ---

            % Total transmit power
            P_tx_max = obj.P_tx_max;

            % Calculate noise variance (sigma2) for the desired SNR
            SNR_linear = 10^(obj.SNR_dB / 10);
            % Noise variance sigma_n^2 = P_tx_max / SNR
            sigma2 = P_tx_max / SNR_linear;
            inv_sigma2 = 1 / sigma2;  % Precompute 1 / sigma2

            % Amplifier inefficiency
            beta = 1 / obj.eta_PA;  % Amplifier inefficiency

            % Precompute constant part of circuit power
            P_circuit_constant = 2 * obj.P_CP + Nt * obj.P_T + Nr * obj.P_R;

            % Initialize variables
            % Start with maximum number of RF chains
            L_T = L_T_max;

            % Use the first L_T singular values
            sigma_k = singular_values_all(1:L_T);
            a_k = inv_sigma2 * (sigma_k).^2;  % Compute a_k once per L_T

            % Initialize Dinkelbach variables
            nu_old = 0;  % Initial energy efficiency
            G_value = inf;  % Initialize G(P, nu)
            m = 0;

            % Initialize P (initial power allocation), can start with equal power
            P = (P_tx_max / L_T) * ones(L_T, 1);

            % Initialize history arrays
            obj.energyEfficiencyHistory = [];
            obj.spectralEfficiencyHistory = [];

            % --- Dinkelbach Time measurement ---
            dinkelbachStart = tic;

            while abs(G_value) > obj.epsilon && m < obj.maxIterations
                % Compute circuit power for current L_T
                P_circuit = P_circuit_constant ...
                    + L_T * (obj.P_RF_chain + Nt * obj.P_PS) ...
                    + L_T * (obj.P_RF_chain + Nr * obj.P_PS);

                % Solve the optimization problem using CVX
                cvx_begin quiet
                    cvx_precision high
                    variable P(L_T) nonnegative;
                    maximize (sum(log(1 + a_k .* P)) - nu_old * (beta * sum(P) + P_circuit))
                    subject to
                        sum(P) <= P_tx_max;
                cvx_end

                % Apply thresholding to P_k
                threshold = 1e-9;  % Define a suitable threshold
                active_indices = find(P > threshold);
                L_T_new = length(active_indices);
                if L_T_new < L_T
                    % Reduce L_T and update variables accordingly
                    L_T = L_T_new;
                    P = P(active_indices);
                    sigma_k = sigma_k(active_indices);
                    a_k = a_k(active_indices);
                    % Continue without resetting m
                end

                % Compute spectral efficiency R(P)
                R_P = sum(log2(1 + a_k .* P));

                % Total transmit power (sum of allocated powers)
                tr_P_TX = sum(P);

                % Compute total power consumption
                P_total = beta * tr_P_TX + P_circuit;

                % Compute G(P, nu)
                G_value = R_P - nu_old * P_total;

                % Update nu
                nu_new = R_P / P_total;

                % Store energy efficiency and spectral efficiency
                obj.energyEfficiencyHistory = [obj.energyEfficiencyHistory; nu_new];
                obj.spectralEfficiencyHistory = [obj.spectralEfficiencyHistory; R_P];

                % Update variables for next iteration
                nu_old = nu_new;
                m = m + 1;
            end

            obj.dinkelbachTime = toc(dinkelbachStart);
            % --- End of Dinkelbach Time measurement ---

            % --- Data Communication Time measurement ---
            dataCommStart = tic;

            % After convergence, compute final rate
            % Construct F_RF and F_BB using the right singular vectors
            F_RF = V(:, active_indices);
            F_BB = eye(L_T);
            % Similarly, construct W_RF and W_BB using the left singular vectors
            W_RF = U(:, active_indices);
            W_BB = eye(L_T);

            % Construct P_TX as a diagonal matrix
            P_TX = diag(P);

            % Compute the effective channel
            H_eff = W_RF' * H * F_RF;

            % Compute rate
            R_final = real(log2(det(eye(L_T) + (1 / sigma2) * W_BB' * H_eff * P_TX * H_eff' * W_BB)));

            % Update spectral efficiency
            obj.spectralEfficiency = R_final;

            % Update energy efficiency using the final spectral efficiency
            obj.energyEfficiency = R_final / P_total;

            obj.dataCommTime = toc(dataCommStart);
            % --- End of Data Communication Time measurement ---

            % Total time
            obj.totalTime = toc(totalTimeStart);

        end

    end
end
