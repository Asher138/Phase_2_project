classdef BruteForce < handle

    properties
        channelSimulation   % Object of the channel simulation (e.g., ChannelGeneration)
        SNR_dB              % Signal-to-Noise Ratio in dB
        spectralEfficiency  % Spectral efficiency calculated for the beamforming scheme
        energyEfficiency    % Energy efficiency calculated for the beamforming scheme
        % Hardware power consumption parameters (in Watts)
        P_RF_chain = 100e-3;  % Power per RF chain (100 mW)
        P_PS = 10e-3;         % Power per phase shifter (10 mW)
        P_CP = 10;            % Computational processing power (e.g., 10 W)
        P_T = 10e-3;          % Power per transmit antenna (10 mW)
        P_R = 10e-3;          % Power per receive antenna (10 mW)
        eta_PA = 0.4;         % Amplifier efficiency (1/beta = 0.4)
        P_tx_max = 10;        % Maximum transmit power in Watts
        optimalLt            % Optimal number of transmit RF chains
        % Timing measurements
        beamTrainingTime     % Time taken for Beam Training part
        bruteForceTime       % Time taken for Brute Force part
        dataCommTime         % Time taken for Data Communication part
        totalTime            % Total time taken
    end

    methods
        function obj = BruteForce(SNR_dB, Channel)
            % Constructor to initialize SNR and channel simulation object.
            obj.channelSimulation = Channel;
            obj.SNR_dB = SNR_dB;  % SNR in dB
            obj.launch();   % Launch the beamforming process
        end

        function obj = launch(obj)
            % Main function to perform hybrid beamforming using a brute-force method.

            % Start total timing
            totalTimeStart = tic;

            %% Beam Training Part
            beamTrainingStart = tic;
            % Extract the channel matrix from the channel simulation object
            H = obj.channelSimulation.channelMatrix;
            % (Additional beam training operations can be included here)
            obj.beamTrainingTime = toc(beamTrainingStart);

            %% Brute Force Part
            bruteForceStart = tic;
            % Number of data streams
            Ns = obj.channelSimulation.numberDataStreams;
            Nr = obj.channelSimulation.numberReceiveAntennas;
            Nt = obj.channelSimulation.numberTransmitAntennas;

            % Maximum number of RF chains to consider
            L_t_min = Ns;    % Minimum number of RF chains (must support Ns data streams)
            L_t_max = min(Nt, 16);  % Maximum number of RF chains (e.g., up to 16)

            % Initialize arrays to store results
            numConfigs = L_t_max - L_t_min + 1;
            energyEfficiencyArray = zeros(numConfigs, 1);
            spectralEfficiencyArray = zeros(numConfigs, 1);
            L_t_values = L_t_min:L_t_max;

            % Noise variance sigma_n^2
            k = 1.38e-23;      % Boltzmann's constant (Joule per Kelvin)
            T = 290;           % System temperature (Kelvin)
            B = 1;             % Bandwidth (Hz), adjust according to your system
            sigma2 = k * T * B;

            % Compute desired SNR in linear scale
            SNR_linear = 10^(obj.SNR_dB / 10);

            % Compute transmit power required to achieve desired SNR
            P_tx = SNR_linear * sigma2;

            % Ensure transmit power does not exceed maximum allowed
            P_tx = min(P_tx, obj.P_tx_max);

            index = 1;
            for L_t = L_t_min:L_t_max
                % Precoding and Combining Matrices Calculation
                % Number of phase shifters
                N_PS = Nt * L_t;

                % Generate analog precoder (constant modulus constraint)
                F_analog = exp(1j * rand(Nt, L_t) * 2 * pi);
                % Normalize F_analog
                F_analog = F_analog / sqrt(Nt);

                % Effective channel after analog precoding
                H_eff = H * F_analog;

                % Perform SVD on effective channel
                [U_eff, ~, V_eff] = svd(H_eff);

                % Number of data streams (Ns_current) cannot exceed L_t and rank of H_eff
                Ns_current = min([Ns, L_t, rank(H_eff)]);

                % Digital precoder (L_t x Ns_current)
                F_digital = V_eff(:, 1:Ns_current);

                % Combine analog and digital precoders
                F_hybrid = F_analog * F_digital;

                % Compute total power of the hybrid precoder before scaling
                total_power = norm(F_hybrid, 'fro')^2;

                % Scaling factor to ensure transmit power constraint is met
                scaling_factor = sqrt(P_tx / total_power);

                % Scale the hybrid precoder
                F_hybrid = F_hybrid * scaling_factor;

                % Digital combiner at receiver
                W_digital = U_eff(:, 1:Ns_current);

                % Compute the effective baseband channel
                Heff = W_digital' * H * F_hybrid;

                % Compute the spectral efficiency
                gamma = zeros(Ns_current, 1);
                for k_idx = 1:Ns_current
                    h_k = Heff(k_idx, :);
                    gamma(k_idx) = (norm(h_k)^2) / sigma2;
                end
                spectralEfficiency = sum(log2(1 + gamma));

                % Total transmit power used after scaling
                tr_P_TX = norm(F_hybrid, 'fro')^2;

                % Total Power Consumption Calculation
                beta = 1 / obj.eta_PA;

                % Total power consumption calculation
                totalPower = beta * tr_P_TX + 2 * obj.P_CP + Nt * obj.P_T + Nr * obj.P_R ...
                    + L_t * (obj.P_RF_chain + Nr * obj.P_PS) + L_t * (obj.P_RF_chain + Nt * obj.P_PS);

                % Compute the energy efficiency
                energyEfficiency = spectralEfficiency / totalPower;

                % Store the results
                energyEfficiencyArray(index) = energyEfficiency;
                spectralEfficiencyArray(index) = spectralEfficiency;
                L_t_values(index) = L_t;

                index = index + 1;
            end
            % End timing for Brute Force part
            obj.bruteForceTime = toc(bruteForceStart);

            %% Data Communication Part
            dataCommStart = tic;
            % Find the L_t that gives maximum energy efficiency
            [maxEnergyEfficiency, maxIndex] = max(energyEfficiencyArray);

            % Set the final spectral efficiency and energy efficiency
            obj.spectralEfficiency = spectralEfficiencyArray(maxIndex);
            obj.energyEfficiency = maxEnergyEfficiency;

            % Store the optimal number of RF chains
            obj.optimalLt = L_t_values(maxIndex);

            % (Additional data communication operations can be included here if applicable)

            % End timing for Data Communication part
            obj.dataCommTime = toc(dataCommStart);

            % Total time taken
            obj.totalTime = toc(totalTimeStart);
        end
    end
end
