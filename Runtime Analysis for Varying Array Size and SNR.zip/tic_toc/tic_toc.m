clear all
arraySizes = [16, 32, 64, 128, 256]; % Different array sizes (number of transmit antennas)
tryNumber = 100; % Number of channel realizations for averaging

%% Simulation Parameters (fixed parameters)
parameters = containers.Map('KeyType','char','ValueType','any');
parameters("numberReceiveAntennas") = 16; % Number of receive antennas (N_R)
parameters("numberDataStreams") = 4; % Number of data streams (N_s)
parameters("numberRFChains") = 4; % Number of RF chains
parameters("numberCluster") = 8; % Number of clusters (N_cl)
parameters("numberRayPerCluster") = 10; % Number of rays per cluster (N_ray)
parameters("angularSpread") = 7.5; % Angular spread in degrees
parameters("meanAODRange") = [60, 120]; % Mean angles of departure range in degrees
parameters("meanAOARange") = [80, 100]; % Mean angles of arrival range in degrees
parameters("angleDistribution") = 'Laplacian'; % Angle distribution

% Hardware power consumption parameters (in Watts)
P_RF_chain = 100e-3;  % Power per RF chain (100 mW)
P_CP = 34.5;          % Computational processing power (34.5 W)
P_PA = 300e-3;        % Power per power amplifier output (300 mW)
P_PS = 10e-3;         % Power per phase shifter (10 mW)
P_T = 10e-3;          % Power per transmit antenna (10 mW)
P_R = 10e-3;          % Power per receive antenna (10 mW)
eta_PA = 0.4;         % Amplifier efficiency (1/beta = 0.4)
P_tx_max = 1;         % Maximum transmit power in Watts

% Define SNR values for the simulation
SNR_dB_values = [-5, 0, 10, 20]; % SNR values in dB

% Initialize matrices to store total computation times
numSNR = length(SNR_dB_values); % Number of SNR values
numArraySizes = length(arraySizes); % Number of array sizes

% Preallocate timing arrays with an extra dimension for SNR
totalTimeDigitalArray = zeros(tryNumber, numArraySizes, numSNR);
totalTimeAnalogArray = zeros(tryNumber, numArraySizes, numSNR);
totalTimeBruteForceArray = zeros(tryNumber, numArraySizes, numSNR);
totalTimePCEMArray = zeros(tryNumber, numArraySizes, numSNR);
totalTimeDinkelbachArray = zeros(tryNumber, numArraySizes, numSNR);

% Create progress bar
h = waitbar(0, 'Progress...');

totalSteps = numSNR * numArraySizes * tryNumber; % Total steps
currentStep = 0; % Current progress

% Loop over SNR values
for snrIdx = 1:numSNR
    SNR_dB = SNR_dB_values(snrIdx); % Current SNR value
    
    % Loop over array sizes
    for idx = 1:numArraySizes
        Nt = arraySizes(idx);
        parameters("numberTransmitAntennas") = Nt; % Set the number of transmit antennas
        parameters("numberRFChains") = min(16, Nt); % Adjust number of RF chains if necessary
        
        % Loop over the number of trials
        for i = 1:tryNumber
            % Generate the channel
            channel = ChannelGeneration(parameters);
            
            %% Digital Beamforming
            totalTimeStart = tic;
            digitalBF = DigitalBeamforming(SNR_dB, channel);
            % Set hardware power parameters
            digitalBF.P_RF_chain = P_RF_chain;
            digitalBF.P_CP = P_CP;
            digitalBF.P_T = P_T;
            digitalBF.P_R = P_R;
            digitalBF.eta_PA = eta_PA;
            % Total computation time for Digital Beamforming
            totalTimeDigitalArray(i, idx, snrIdx) = toc(totalTimeStart);
            
            %% Analog Beamforming
            totalTimeStart = tic;
            analogBF = AnalogBeamforming(SNR_dB, channel);
            % Set hardware power parameters
            analogBF.P_RF_chain = P_RF_chain;
            analogBF.P_PS = P_PS;
            analogBF.P_CP = P_CP;
            analogBF.P_T = P_T;
            analogBF.P_R = P_R;
            analogBF.eta_PA = eta_PA;
            analogBF.P_tx_max = P_tx_max;
            % Total computation time for Analog Beamforming
            totalTimeAnalogArray(i, idx, snrIdx) = toc(totalTimeStart);
            
            %% Brute Force Method
            totalTimeStart = tic;
            bruteForceBF = BruteForce(SNR_dB, channel);
            % Set hardware power parameters
            bruteForceBF.P_RF_chain = P_RF_chain;
            bruteForceBF.P_T = P_T;
            bruteForceBF.P_R = P_R;
            bruteForceBF.P_CP = P_CP;
            bruteForceBF.P_PS = P_PS;
            bruteForceBF.eta_PA = eta_PA;
            bruteForceBF.P_tx_max = P_tx_max;
            % Total computation time for Brute Force Method
            totalTimeBruteForceArray(i, idx, snrIdx) = toc(totalTimeStart);
            
            %% PCEM Method
            totalTimeStart = tic;
            L_t = parameters("numberRFChains"); % Number of transmit RF chains
            pcemBF = PCEM(SNR_dB, channel, L_t);
            % Set hardware power parameters
            pcemBF.P_RF_chain = P_RF_chain;
            pcemBF.P_PS = P_PS;
            pcemBF.P_CP = P_CP;
            pcemBF.P_T = P_T;
            pcemBF.P_R = P_R;
            pcemBF.eta_PA = eta_PA;
            % Total computation time for PCEM Method
            totalTimePCEMArray(i, idx, snrIdx) = toc(totalTimeStart);
            
            %% Dinkelbach Method
            totalTimeStart = tic;
            dinkelbachBF = DinkelbachMethod(SNR_dB, channel);
            % Set hardware power parameters
            dinkelbachBF.P_RF_chain = P_RF_chain;
            dinkelbachBF.P_PS = P_PS;
            dinkelbachBF.P_CP = P_CP;
            dinkelbachBF.P_T = P_T;
            dinkelbachBF.P_R = P_R;
            dinkelbachBF.eta_PA = eta_PA;
            dinkelbachBF.P_tx_max = P_tx_max;
            % Total computation time for Dinkelbach Method
            totalTimeDinkelbachArray(i, idx, snrIdx) = toc(totalTimeStart);
            
            % Update progress bar
            currentStep = currentStep + 1;
            waitbar(currentStep / totalSteps, h, sprintf('Progress: %d%%', round(100 * currentStep / totalSteps)));
        end
    end
end

% Close progress bar
close(h);

% Averaging total computation times over trials
avgTotalTimeDigitalArray = mean(totalTimeDigitalArray, 1); % Dimensions: [1, numArraySizes, numSNR]
avgTotalTimeAnalogArray = mean(totalTimeAnalogArray, 1);
avgTotalTimeBruteForceArray = mean(totalTimeBruteForceArray, 1);
avgTotalTimePCEMArray = mean(totalTimePCEMArray, 1);
avgTotalTimeDinkelbachArray = mean(totalTimeDinkelbachArray, 1);

% Squeeze the first dimension as it's singleton after mean operation
avgTotalTimeDigitalArray = squeeze(avgTotalTimeDigitalArray); % Dimensions: [numArraySizes, numSNR]
avgTotalTimeAnalogArray = squeeze(avgTotalTimeAnalogArray);
avgTotalTimeBruteForceArray = squeeze(avgTotalTimeBruteForceArray);
avgTotalTimePCEMArray = squeeze(avgTotalTimePCEMArray);
avgTotalTimeDinkelbachArray = squeeze(avgTotalTimeDinkelbachArray);

% Plotting the runtime vs array size for each SNR
figure();
markers = {'-o', '-x', '-s', '-d', '-^'};
methods = {'Digital Beamforming', 'Analog Beamforming', 'Brute Force', 'PCEM Method', 'Dinkelbach Method'};
colors = lines(3); % We will plot only 3 SNR values (excluding -5 dB)

% Indices of SNR_dB_values that we want to plot
plot_snr_indices = find(SNR_dB_values ~= -5);

% For each method, plot runtime vs array size for each SNR
for methodIdx = 1:length(methods)
    subplot(2,3,methodIdx);
    hold on;
    legendEntries = {};
    colorIdx = 1;
    for snrIdx = plot_snr_indices
        switch methodIdx
            case 1
                avgTime = avgTotalTimeDigitalArray(:, snrIdx);
            case 2
                avgTime = avgTotalTimeAnalogArray(:, snrIdx);
            case 3
                avgTime = avgTotalTimeBruteForceArray(:, snrIdx);
            case 4
                avgTime = avgTotalTimePCEMArray(:, snrIdx);
            case 5
                avgTime = avgTotalTimeDinkelbachArray(:, snrIdx);
        end
        snrValue = SNR_dB_values(snrIdx);
        semilogy(arraySizes, avgTime, markers{colorIdx}, 'LineWidth', 2.0, 'MarkerSize', 8.0, 'Color', colors(colorIdx,:), 'DisplayName', sprintf('SNR = %d dB', snrValue));
        legendEntries{end+1} = sprintf('SNR = %d dB', snrValue);
        colorIdx = colorIdx + 1;
    end
    hold off;
    xlabel('Number of Transmit Antennas (Array Size)', 'FontSize', 12);
    ylabel('Average Runtime (seconds)', 'FontSize', 12);
    title(methods{methodIdx}, 'FontSize', 14);
    legend('show', 'Location', 'northwest', 'FontSize', 10);
    grid on;
end

% Adjust the layout
sgtitle('Runtime vs Array Size for Different SNR Values', 'FontSize', 16);
