classdef PCEM < handle

    properties
        channelSimulation   % Object of the channel simulation (e.g., ChannelGeneration)
        spectralEfficiency  % Spectral efficiency calculated for the beamforming scheme (bits/s/Hz)
        energyEfficiency    % Energy efficiency calculated for the beamforming scheme (bits/Joule)
        % Hardware power consumption parameters (in Watts)
        P_RF_chain = 100e-3;  % Power per RF chain (100 mW)
        P_PS = 10e-3;         % Power per phase shifter (10 mW)
        P_CP = 10;            % Computational processing power (10 W)
        P_T = 10e-3;          % Power per transmit antenna (10 mW)
        P_R = 10e-3;          % Power per receive antenna (10 mW)
        eta_PA = 0.4;         % Amplifier efficiency (1/beta = 0.4)
        optimalPt            % Optimal transmit power (Watts)
        L_t                  % Number of transmit RF chains (input)
        SNR_dB               % Desired Signal-to-Noise Ratio in dB
        % Timing measurements
        beamTrainingTime     % Time taken for Beam Training part
        pcemTime             % Time taken for PCEM computation part
        dataCommTime         % Time taken for Data Communication part
        totalTime            % Total time taken
    end

    methods
        function obj = PCEM(SNR_dB, Channel, L_t)
            % Constructor to initialize SNR, channel simulation object, and number of RF chains.
            obj.SNR_dB = SNR_dB;
            obj.channelSimulation = Channel;
            obj.L_t = L_t;  % Set L_t from input
            obj.launch();  % Launch the beamforming process
        end

        function obj = launch(obj)
            % Main function to perform hybrid beamforming using the PCEM method.

            % Start total timing
            totalTimeStart = tic;

            %% Beam Training Part
            beamTrainingStart = tic;

            % System parameters
            fc = 28e9;          % Carrier frequency (Hz)
            c = 3e8;            % Speed of light (m/s)
            gamma = 2;          % Path loss exponent
            d = 100;            % Distance in meters

            % Calculate path loss
            lambda = c / fc;    % Wavelength (m)
            pathLoss_linear = (4 * pi * d / lambda)^gamma;

            % Extract the channel matrix from the channel simulation object
            H = obj.channelSimulation.channelMatrix;

            % Apply path loss to channel matrix
            H = H / sqrt(pathLoss_linear);

            % End beam training timing
            obj.beamTrainingTime = toc(beamTrainingStart);

            %% PCEM Part
            pcemStart = tic;

            % Number of data streams
            Ns = obj.channelSimulation.numberDataStreams;
            Nr = obj.channelSimulation.numberReceiveAntennas;
            Nt = obj.channelSimulation.numberTransmitAntennas;
            L_t = obj.L_t;  % Use the input L_t

            % Generate the fully digital precoder using SVD of H
            [~, ~, V] = svd(H);
            V_D = V(:, 1:Ns);  % Fully digital precoder (N_t x N_s)

            if L_t == Nt
                % Fully digital system
                F_analog = eye(Nt);  % Identity matrix
                F_digital = V_D;     % Use the first Ns right singular vectors
                % Normalize the digital precoder
                F_digital = F_digital / norm(F_digital, 'fro') * sqrt(Ns);
            else
                % Hybrid precoding
                % Initialize the analog precoder using the phases of the fully digital precoder
                if L_t <= Ns
                    F_analog = exp(1j * angle(V_D(:, 1:L_t)));
                else
                    % Use V(:, 1:L_t) when L_t > Ns
                    F_analog = exp(1j * angle(V(:, 1:L_t)));
                end
                % Ensure unit modulus constraint and normalize
                F_analog = F_analog / sqrt(Nt);

                % Use Alternating Minimization to solve the optimization problem
                max_iterations = 100;
                tol = 1e-8;
                epsilon = 1e-6;  % Regularization parameter
                F_digital = zeros(L_t, Ns);
                for iter = 1:max_iterations
                    % Solve for digital precoder given analog precoder
                    % Regularized least squares solution to avoid ill-conditioning
                    F_digital = (F_analog' * F_analog + epsilon * eye(L_t)) \ (F_analog' * V_D);

                    % Normalize digital precoder to maintain power constraint
                    normalization_factor = norm(F_analog * F_digital, 'fro');
                    if normalization_factor == 0
                        normalization_factor = eps;  % Avoid division by zero
                    end
                    F_digital = F_digital / normalization_factor * sqrt(Ns);

                    % Update analog precoder
                    F_analog_old = F_analog;
                    numerator = V_D * F_digital';
                    F_analog = exp(1j * angle(numerator));
                    % Ensure unit modulus constraint and normalize
                    F_analog = F_analog / sqrt(Nt);

                    % Check for convergence
                    if norm(F_analog - F_analog_old, 'fro') / norm(F_analog_old, 'fro') < tol
                        break;
                    end
                end
            end

            % Effective channel after hybrid precoding
            H_eff = H * F_analog * F_digital;

            % Generate the fully digital combiner using SVD of H_eff
            [U_eff, S_eff, ~] = svd(H_eff);

            % Digital combiner at receiver
            W_digital = U_eff(:, 1:Ns);

            % End PCEM timing
            obj.pcemTime = toc(pcemStart);

            %% Data Communication Part
            dataCommStart = tic;

            % Compute the effective baseband channel
            Heff = W_digital' * H_eff;

            % Compute singular values (gains) for each stream
            singular_values = diag(S_eff(1:Ns, 1:Ns));

            % Implement PCEM Algorithm to find optimal transmit power
            % Constants for PCEM
            beta = 1 / obj.eta_PA;  % Amplifier inefficiency factor

            % Total circuit power consumption (excluding transmit power)
            if L_t == Nt
                % Fully digital system
                Pc = 2 * obj.P_CP + Nt * (obj.P_RF_chain + obj.P_T) + Nr * (obj.P_RF_chain + obj.P_R);
            else
                % Hybrid beamforming system
                Pc = 2 * obj.P_CP + Nt * obj.P_T + Nr * obj.P_R ...
                    + L_t * (obj.P_RF_chain + Nt * obj.P_PS) ...
                    + L_t * (obj.P_RF_chain + Nr * obj.P_PS);
            end

            % Noise variance sigma_n^2 (thermal noise)
            k = 1.38e-23;       % Boltzmann's constant (Joule per Kelvin)
            T = 290;            % System temperature (Kelvin)
            B = 1e6;            % Bandwidth (Hz)
            sigma2_noise = k * T * B;

            % Compute the total channel gain
            G = sum(singular_values.^2);

            % Desired SNR in linear scale
            SNR_linear_desired = 10^(obj.SNR_dB / 10);

            % Minimum transmit power to meet SNR constraint
            Pt_min = SNR_linear_desired * Ns * sigma2_noise / G;

            % Define the energy efficiency function to maximize
            EE_fun = @(Pt) - (sum(log2(1 + (Pt * singular_values.^2) / (Ns * sigma2_noise)))) / (beta * Pt + Pc);

            % Define constraint function (ensure Pt >= Pt_min)
            constraint_fun = @(Pt) Pt - Pt_min;

            % Define the objective function with penalty for violating the constraint
            obj_fun = @(Pt) objective_with_penalty(Pt, EE_fun, constraint_fun);

            % Use fminbnd to find the optimal Pt over a reasonable range
            Pt_max_search = Pt_min * 100;  % Search up to 100 times the minimum required power

            % Ensure Pt_max_search is reasonable
            if Pt_max_search < 1e-6
                Pt_max_search = 1;  % Set to 1 Watt if too small
            end

            options = optimset('TolX', 1e-6, 'Display', 'off');

            [Pt_opt, ~] = fminbnd(obj_fun, Pt_min, Pt_max_search, options);

            % Compute the achieved spectral efficiency
            gamma = (Pt_opt * singular_values.^2) / (Ns * sigma2_noise);
            spectralEfficiency = sum(log2(1 + gamma));

            % Compute total power consumption
            totalPower = beta * Pt_opt + Pc;

            % Compute energy efficiency
            energyEfficiency = spectralEfficiency / totalPower;  % bits/Joule

            % Store the results
            obj.spectralEfficiency = spectralEfficiency;
            obj.energyEfficiency = energyEfficiency;
            obj.optimalPt = Pt_opt;

            % End data communication timing
            obj.dataCommTime = toc(dataCommStart);

            % End total timing
            obj.totalTime = toc(totalTimeStart);
        end
    end
end

% Objective function with penalty for constraint violation
function val = objective_with_penalty(Pt, EE_fun, constraint_fun)
    penalty = 1e6;
    if constraint_fun(Pt) >= 0
        val = EE_fun(Pt);
    else
        val = EE_fun(Pt) + penalty * abs(constraint_fun(Pt));
    end
end
