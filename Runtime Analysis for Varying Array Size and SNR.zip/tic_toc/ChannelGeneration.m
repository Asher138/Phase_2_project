classdef ChannelGeneration < handle
    % Simulation of channel environment and optimization types.

    properties
        numberTransmitAntennas  % Number of transmit antennas
        numberReceiveAntennas   % Number of receive antennas
        numberDataStreams       % Number of data streams
        numberRFChains          % Number of RF chains used for precoding and combining
        numberCluster           % Number of clusters (N_cl)
        numberRayPerCluster     % Number of rays per cluster (N_ray)
        angularSpread           % Angular spread in degrees
    end
    properties (Access=public)
        channelMatrix           % Channel matrix for the MIMO system
        arrayResponseTx         % Array response vector for the transmitter
        arrayResponseRx         % Array response vector for the receiver
        alpha                   % Complex path gain for each ray
    end

    methods
        function obj = ChannelGeneration(parameters)
            % Constructor to initialize the parameters from input.
            obj.numberTransmitAntennas = parameters("numberTransmitAntennas");
            obj.numberReceiveAntennas = parameters("numberReceiveAntennas");
            obj.numberDataStreams = parameters("numberDataStreams");
            obj.numberRFChains = parameters("numberRFChains");
            obj.numberCluster = parameters("numberCluster");
            obj.numberRayPerCluster = parameters("numberRayPerCluster");
            obj.angularSpread = parameters("angularSpread");
            obj.launch();  % Call the launch function to simulate the channel
        end

        function obj = launch(obj)
            % Main function to simulate the channel and calculate all required properties.

            % Define azimuth angle range for clusters in degrees
            phi_t_min = -60;  % Minimum angle of departure (AOD)
            phi_t_max = 60;   % Maximum angle of departure (AOD)
            phi_r_min = -60;  % Minimum angle of arrival (AOA)
            phi_r_max = 60;   % Maximum angle of arrival (AOA)

            % Randomly generate cluster angles for both AOD (transmitter) and AOA (receiver)
            clusterAOD = rand(obj.numberCluster, 1) * (phi_t_max - phi_t_min) + phi_t_min; % Cluster AOD values in degrees
            clusterAOA = rand(obj.numberCluster, 1) * (phi_r_max - phi_r_min) + phi_r_min; % Cluster AOA values in degrees

            % Define angular spread scaling factor
            b = obj.angularSpread / sqrt(2);  % Scale factor for angular spread, in degrees

            % Generate angles for each ray by adding random variation to the cluster angles
            rndm = randn(obj.numberRayPerCluster * obj.numberCluster, 1); % Random Gaussian variables for ray angles
            rayAOD = repelem(clusterAOD, obj.numberRayPerCluster, 1) + b * rndm; % AOD for each ray
            rayAOA = repelem(clusterAOA, obj.numberRayPerCluster, 1) + b * rndm; % AOA for each ray

            % Convert angles from degrees to radians
            rayAOD_rad = deg2rad(rayAOD);  % AOD in radians
            rayAOA_rad = deg2rad(rayAOA);  % AOA in radians

            % Obtain the position vectors of antennas for both transmitter and receiver arrays
            [txPosition, rxPosition] = obj.obtainPositionVectors();

            % Compute array response vectors based on the antenna positions and ray angles
            obj.arrayResponseTx = (1 / sqrt(obj.numberTransmitAntennas)) * exp(1i * pi * txPosition * sin(rayAOD_rad.'));
            obj.arrayResponseRx = (1 / sqrt(obj.numberReceiveAntennas)) * exp(1i * pi * rxPosition * sin(rayAOA_rad.'));

            % Generate complex path gains for each ray (channel coefficient)
            obj.generateComplexGainPath();

            % Generate the complete MIMO channel matrix using the computed array responses and path gains
            obj.generateChannelMatrix();
        end

        function [txPosition, rxPosition] = obtainPositionVectors(obj)
            %% Obtain the position vectors of antenna elements (normalized by half-wavelength)
            % Transmit antenna array positions - Uniform Linear Array (ULA) along the Z-axis
            txPosition = (0:obj.numberTransmitAntennas - 1).'; % Position vector of transmitter antennas (N_T x 1)

            % Receive antenna array positions - ULA along the Z-axis
            rxPosition = (0:obj.numberReceiveAntennas - 1).'; % Position vector of receiver antennas (N_R x 1)
        end

        function obj = generateComplexGainPath(obj)
            % Compute normalization factor gamma
            gamma = sqrt((obj.numberTransmitAntennas * obj.numberReceiveAntennas) / ...
                (obj.numberCluster * obj.numberRayPerCluster));

            % Assign sigma_alpha_i^2 such that sum_i sigma_alpha_i^2 = gamma
            % Assuming equal power allocation across clusters
            sigma_alpha_i_squared = gamma / obj.numberCluster;
            sigma_alpha_vector = sigma_alpha_i_squared * ones(obj.numberCluster, 1);

            % Expand sigma_alpha_vector to match the number of rays
            sigma_alpha_expanded = repelem(sigma_alpha_vector, obj.numberRayPerCluster);

            % Generate complex path gains for each ray
            obj.alpha = sqrt(sigma_alpha_expanded / 2) .* (randn(length(sigma_alpha_expanded), 1) + ...
                                                           1i * randn(length(sigma_alpha_expanded), 1));
        end

        function obj = generateChannelMatrix(obj)
            % Compute the MIMO channel matrix for the system
            % Formula: H = sqrt(N_T * N_R / (N_cl * N_ray)) * sum_i sum_l alpha_il * a_R(phi^r_il) * a_T(phi^t_il)^H
            scalingFactor = sqrt((obj.numberTransmitAntennas * obj.numberReceiveAntennas) / ...
                                 (obj.numberCluster * obj.numberRayPerCluster));

            % Construct the channel matrix using matrix operations
            obj.channelMatrix = scalingFactor * obj.arrayResponseRx * diag(obj.alpha) * obj.arrayResponseTx';
        end
    end
end
