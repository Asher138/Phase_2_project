% Parameters
N = 10;          % Number of array elements
d = 0.5;         % Element spacing in wavelengths
lambda = 1;      % Wavelength
k = 2 * pi / lambda;  % Wavenumber

% Define angles for psi_i
psi_deg = linspace(-90, 90, 360);  % Angles from -90° to 90°
psi_rad = deg2rad(psi_deg);        % Convert to radians

% Element indices
n = (0:N-1)';

% Compute the steering vector matrix v(psi_i) (N x length(psi_rad))
v = exp(-1j * k * d * n * sin(psi_rad));

% Define steering angles (theta_0) to steer the beam
steering_angles = [-60, -30, 0, 30, 60];  % Steering angles in degrees

% Prepare to plot
figure;
hold on;
colors = {'r', 'g', 'b', 'k', 'm'};  % For different plots
legend_entries = cell(1, length(steering_angles));

% Loop over steering angles
for idx = 1:length(steering_angles)
    theta_0 = steering_angles(idx);           % Current steering angle
    theta_0_rad = deg2rad(theta_0);           % Convert to radians
    
    % Compute weight vector w for steering
    w = exp(1j * k * d * n * sin(theta_0_rad)) / N;  % Normalize weights
    
    % Compute the beam pattern
    B = w' * v;
    
    % Compute magnitude and normalize
    B_magnitude = abs(B);
    B_normalized = B_magnitude / max(B_magnitude);
    
    % Convert to decibels and set floor
    B_dB = 20 * log10(B_normalized);
    B_dB = max(B_dB, -60);  % Avoid values below -60 dB
    
    % Plot the beam pattern
    plot(psi_deg, B_dB, 'LineWidth', 2, 'Color', colors{idx});
    legend_entries{idx} = ['Steering Angle = ', num2str(theta_0), '°'];
end

% Finalize the plot
xlabel('Angle \psi (degrees)');
ylabel('Beam Pattern |B(\psi)| (dB)');
title('Beam Pattern vs. Angle for Different Steering Angles');
grid on;
axis([-90 90 -60 0]);  % Adjust axis limits
legend(legend_entries, 'Location', 'Best');
hold off;
